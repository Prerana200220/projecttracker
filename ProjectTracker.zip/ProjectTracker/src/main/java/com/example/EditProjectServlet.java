package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

// Uncomment or adjust your mapping as needed:
// @WebServlet("/editProject")
public class EditProjectServlet extends HttpServlet {

    // Show the edit form (GET request)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String projectIdStr = request.getParameter("projectId");
        if (projectIdStr == null) {
            response.getWriter().println("<h3>No project ID provided!</h3>");
            return;
        }
        try {
            int projectId = Integer.parseInt(projectIdStr);
            ProjectDAO dao = new ProjectDAO();
            Project project = dao.getProjectById(projectId);
            if (project == null) {
                response.getWriter().println("<h3>Project not found!</h3>");
            } else {
                // Put the project in request scope
                request.setAttribute("project", project);
                // Forward to the JSP
                request.getRequestDispatcher("editProject.jsp").forward(request, response);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace(response.getWriter());
        }
    }

    // Process the edit form submission (POST request)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Parse the project ID
            int projectId = Integer.parseInt(request.getParameter("projectId"));
            
            // Retrieve the updated fields
            String jobNo = request.getParameter("jobNo");
            String customer = request.getParameter("customer");
            String city = request.getParameter("city");
            String region = request.getParameter("region");
            String segment = request.getParameter("segment");
            String projectManager = request.getParameter("projectManager");
            String projectName = request.getParameter("projectName");
            
            // Project value (in INR)
            long projectValue = Long.parseLong(request.getParameter("projectValue"));
            
            // Currency for display
            String currency = request.getParameter("currency");

            // Retrieve payment terms
            String paymentTerms = request.getParameter("paymentTerms");
            
            // Retrieve customer required date (if provided)
            String customerRequiredDateStr = request.getParameter("customerRequiredDate");
            Date customerRequiredDate = null;
            if (customerRequiredDateStr != null && !customerRequiredDateStr.trim().isEmpty()) {
                customerRequiredDate = Date.valueOf(customerRequiredDateStr);
            }

            // Create a project object with updated data
            Project project = new Project();
            project.setId(projectId);
            project.setJobNo(jobNo);
            project.setCustomer(customer);
            project.setCity(city);
            project.setRegion(region);
            project.setSegment(segment);
            project.setProjectManager(projectManager);
            project.setProjectName(projectName);
            project.setProjectValue(projectValue); // stored as INR
            project.setCurrency(currency);
            project.setPaymentTerms(paymentTerms);
            project.setCustomerRequiredDate(customerRequiredDate);

            // Update in DB
            ProjectDAO dao = new ProjectDAO();
            boolean updated = dao.updateProject(project);
            if (updated) {
                response.sendRedirect("dashboard");
            } else {
                response.getWriter().println("<h3>Error updating project</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace(response.getWriter());
        }
    }
}
