package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

@WebServlet("/updatePlannedDate")
public class UpdatePlannedDateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Parse parameters from the update form.
            int itemId = Integer.parseInt(request.getParameter("itemId"));
            int projectId = Integer.parseInt(request.getParameter("projectId"));
            String newPlannedDateStr = request.getParameter("newPlannedDate");
            String newDelayReason = request.getParameter("newDelayReason");  // New reason for delay

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date newPlannedDate = sdf.parse(newPlannedDateStr);

            // Retrieve the current item from the database.
            ItemDAO itemDao = new ItemDAO();
            Item item = itemDao.getItemById(itemId);
            if (item == null) {
                response.getWriter().println("<h3>Item not found!</h3>");
                return;
            }

            // Retrieve project details from the projects table.
            ProjectDAO projectDao = new ProjectDAO();
            Project project = projectDao.getProjectById(projectId);
            if (project == null) {
                response.getWriter().println("<h3>Project not found!</h3>");
                return;
            }
            String jobNo = project.getJobNo();
            // Retrieve customer from the project table.
            String customer = project.getCustomer();

            Date oldPlannedDate = item.getPlannedDate();
            // Check if the planned date is actually changing.
            if (oldPlannedDate != null && sdf.format(oldPlannedDate).equals(sdf.format(newPlannedDate))) {
                response.getWriter().println("<h3>The planned date has not changed.</h3>");
                return;
            }

            // Update the item with the new planned date and delay reason.
            item.setPlannedDate(newPlannedDate);
            item.setDelayReason(newDelayReason);
            boolean updated = itemDao.updateItem(item);
            if (updated) {
                // Send email notification to MD with details including item description,
                // project job number, and customer.
                sendEmailToMD(oldPlannedDate, newPlannedDate, newDelayReason, jobNo, customer, item.getItemDescription());
                // Redirect to the view items page.
                response.sendRedirect("viewItems?projectId=" + projectId);
            } else {
                response.getWriter().println("<h3>Error updating planned date and delay reason.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Exception: " + e.getMessage());
        }
    }

    private void sendEmailToMD(Date oldDate, Date newDate, String delayReason, String jobNo, String customer, String itemDescription) {
        try {
            // Configure Jakarta Mail properties.
            Properties props = new Properties();
            props.put("mail.smtp.host", "mail.reputeindia.net");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "454");
            props.put("mail.smtp.ssl.enable", "true");

            // Create a mail session with authentication.
            Session mailSession = Session.getInstance(props, new jakarta.mail.Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("projectplanner@reputeindia.net", "projectplanner$#@321");
                }
            });

            // Compose the email.
            Message message = new MimeMessage(mailSession);
            message.setFrom(new InternetAddress("projectplanner@reputeindia.net"));
            // Replace with your MD's email address.
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("preranasalunkhe2002@gmail.com,salunkheep@gmail.com"));
            message.setSubject("Planned Date Updated");

            // Format dates for the email body.
            SimpleDateFormat sdfEmail = new SimpleDateFormat("dd/MM/yyyy");
            String oldDateStr = (oldDate != null) ? sdfEmail.format(oldDate) : "Not Set";
            String newDateStr = sdfEmail.format(newDate);

            // Construct the email body with all required details.
            String body = "Please be informed that the scheduled date for project planning has been changed as below:\n"
            		
                        + "Project Job No: " + jobNo + "\n"
                        + "Customer: " + customer + "\n"
                        + "Item Description: " + itemDescription + "\n"
                        + "Previous Planned Date: " + oldDateStr + "\n"
                        + "New Planned Date: " + newDateStr + "\n"
                        + "Reason for Delay: " + delayReason ;
                       
                       
                      
            message.setText(body);

            // Send the email.
            Transport.send(message);
        } catch (Exception e) {
            e.printStackTrace();
            // Optionally log or handle email sending failure.
        }
    }
}
