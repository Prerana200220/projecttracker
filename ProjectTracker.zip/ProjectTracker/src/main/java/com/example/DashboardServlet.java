package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

public class DashboardServlet extends HttpServlet {
   private static final Logger logger = Logger.getLogger(DashboardServlet.class.getName());

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      HttpSession session = request.getSession();

      // Ensure role is set for session
      if (session.getAttribute("role") == null) {
         session.setAttribute("role", "user");
      }

      // Retrieve search and filter parameters
      String search = request.getParameter("search");
      String filterField = request.getParameter("filterField");
      String filterValue = request.getParameter("filterValue");

      ProjectDAO projectDao = new ProjectDAO();
      List<Project> projects;

      try {
         if (filterField != null && filterValue != null && !filterField.trim().isEmpty() && !filterValue.trim().isEmpty()) {
            projects = projectDao.getFilteredProjects(filterField, filterValue);
            logger.info("Filtered projects retrieved successfully.");
         } else if (search != null && !search.trim().isEmpty()) {
            projects = projectDao.getProjects(search);
            logger.info("Searched projects retrieved successfully.");
         } else {
            projects = projectDao.getProjects(null);
            logger.info("All projects retrieved successfully.");
         }
      } catch (Exception e) {
         logger.severe("Error retrieving projects: " + e.getMessage());
         projects = null; // Ensure the application doesn't break if an error occurs
      }

      // Set projects list in request attribute
      request.setAttribute("projects", projects);
      
      // Forward to JSP page
      request.getRequestDispatcher("dashboard.jsp").forward(request, response);
   }
}
