package com.example;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username"); // Get username from session
        
        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        if (!newPassword.equals(confirmPassword)) {
            request.setAttribute("error", "New password and confirm password do not match!");
            request.getRequestDispatcher("change_password.jsp").forward(request, response);
            return;
        }

        try {
            // Database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project_tracker", "root", "Root@123");

            // Check if user exists and verify current password
            PreparedStatement pst = con.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
            pst.setString(1, username);
            pst.setString(2, currentPassword); // No hashing
            ResultSet rs = pst.executeQuery();

            if (rs.next()) { // User found
                // Update new password (plain text)
                PreparedStatement updatePst = con.prepareStatement("UPDATE users SET password = ? WHERE username = ?");
                updatePst.setString(1, newPassword); // No hashing
                updatePst.setString(2, username);
                int rowCount = updatePst.executeUpdate();

                if (rowCount > 0) {
                    request.setAttribute("message", "Password changed successfully!");
                } else {
                    request.setAttribute("error", "Failed to change password. Try again.");
                }
            } else {
                request.setAttribute("error", "Current password is incorrect!");
            }

            request.getRequestDispatcher("change_password.jsp").forward(request, response);
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Something went wrong. Please try again.");
            request.getRequestDispatcher("change_password.jsp").forward(request, response);
        }
    }
}
