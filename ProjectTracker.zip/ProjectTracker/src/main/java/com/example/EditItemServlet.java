package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/editItem")
public class EditItemServlet extends HttpServlet {

    // Handle GET: Load item details and forward to editItem.jsp
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get existing session; if null, redirect to login.
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userRole") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            int itemId = Integer.parseInt(request.getParameter("itemId"));
            int projectId = Integer.parseInt(request.getParameter("projectId"));
            
            ItemDAO itemDao = new ItemDAO();
            Item item = itemDao.getItemById(itemId);
            if (item == null) {
                response.getWriter().println("<h3>Item not found!</h3>");
                return;
            }
            
            // Set attributes for the JSP.
            request.setAttribute("item", item);
            request.setAttribute("projectId", projectId);
            
            // Forward to the JSP.
            request.getRequestDispatcher("editItem.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid item or project ID.");
        }
    }

    // Handle POST: Process the update from the admin edit page.
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the existing session
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userRole") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            int itemId = Integer.parseInt(request.getParameter("itemId"));
            int projectId = Integer.parseInt(request.getParameter("projectId"));
            String srNo = request.getParameter("srNo"); // Retrieve SR No.
            String erpNo = request.getParameter("erpNo");
            String itemDescription = request.getParameter("itemDescription");
            String capacity = request.getParameter("capacity");
            int qty = Integer.parseInt(request.getParameter("qty"));
            String unitValueStr = request.getParameter("unitValue").replaceAll(",", "");
            double unitValue = Double.parseDouble(unitValueStr);
            String responsibility = request.getParameter("responsibility");
            String status = request.getParameter("status");

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date plannedDate = null;
            String plannedDateStr = request.getParameter("plannedDate");
            if (plannedDateStr != null && !plannedDateStr.trim().isEmpty()) {
                plannedDate = sdf.parse(plannedDateStr);
            }
            Date completedDate = null;
            String completedDateStr = request.getParameter("completedDate");
            if (completedDateStr != null && !completedDateStr.trim().isEmpty()) {
                completedDate = sdf.parse(completedDateStr);
            }
            Date readyBy = null;
            String readyByStr = request.getParameter("ready_by");
            if (readyByStr != null && !readyByStr.trim().isEmpty()) {
                readyBy = sdf.parse(readyByStr);
            }

            // Create the item object and set all fields, including SR No.
            Item item = new Item();
            item.setId(itemId);
            item.setProjectId(projectId);
            item.setSrNo(srNo);  // Set the SR No. from the form
            item.setErpNo(erpNo);
            item.setItemDescription(itemDescription);
            item.setCapacity(capacity);
            item.setQty(qty);
            item.setUnitValue(unitValue);
            // If total_value is generated, it is not updated here; otherwise, include it.
            // item.setTotalValue(totalValue);  // Usually total_value is generated automatically.
            item.setResponsibility(responsibility);
            item.setStatus(status);
            item.setPlannedDate(plannedDate);
            item.setCompletedDate(completedDate);
            item.setReadyBy(readyBy);

            // Update the item.
            ItemDAO itemDao = new ItemDAO();
            boolean updated = itemDao.updateItem(item);
            if (updated) {
                // Redirect back to viewItems page with the same projectId.
                response.sendRedirect("viewItems?projectId=" + projectId);
            } else {
                response.getWriter().println("<h3>Error updating item.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Exception: " + e.getMessage());
        }
    }
}
