package com.example;

public class Item {
    private int id;
    private int projectId;
    private String srNo;  // Add this property
    private String erpNo;
    private String itemDescription;
    private String capacity;
    private int qty;
    private double unitValue;
    private double totalValue;
    private String responsibility;
    private java.util.Date plannedDate;
    private java.util.Date completedDate;
    private String delayReason;
    private String status;
    private java.util.Date readyBy;

    // Getters and setters

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    
    public String getSrNo() {
        return srNo;
    }
    public void setSrNo(String srNo) {
        this.srNo = srNo;
    }
    
    public String getErpNo() {
        return erpNo;
    }
    public void setErpNo(String erpNo) {
        this.erpNo = erpNo;
    }
    
    public String getItemDescription() {
        return itemDescription;
    }
    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }
    
    public String getCapacity() {
        return capacity;
    }
    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }
    
    public int getQty() {
        return qty;
    }
    public void setQty(int qty) {
        this.qty = qty;
    }
    
    public double getUnitValue() {
        return unitValue;
    }
    public void setUnitValue(double unitValue) {
        this.unitValue = unitValue;
    }
    
    public double getTotalValue() {
        return totalValue;
    }
    public void setTotalValue(double totalValue) {
        this.totalValue = totalValue;
    }
    
    public String getResponsibility() {
        return responsibility;
    }
    public void setResponsibility(String responsibility) {
        this.responsibility = responsibility;
    }
    
    public java.util.Date getPlannedDate() {
        return plannedDate;
    }
    public void setPlannedDate(java.util.Date plannedDate) {
        this.plannedDate = plannedDate;
    }
    
    public java.util.Date getCompletedDate() {
        return completedDate;
    }
    public void setCompletedDate(java.util.Date completedDate) {
        this.completedDate = completedDate;
    }
    
    public String getDelayReason() {
        return delayReason;
    }
    public void setDelayReason(String delayReason) {
        this.delayReason = delayReason;
    }
    
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public java.util.Date getReadyBy() {
        return readyBy;
    }
    public void setReadyBy(java.util.Date readyBy) {
        this.readyBy = readyBy;
    }
}
