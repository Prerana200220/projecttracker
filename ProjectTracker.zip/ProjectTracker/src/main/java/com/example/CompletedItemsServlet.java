package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/completedItems")
public class CompletedItemsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
         // Get the projectId parameter from the URL
         String projectIdStr = request.getParameter("projectId");
         int projectId = Integer.parseInt(projectIdStr);
         
         // Retrieve project details using ProjectDAO
         ProjectDAO projectDao = new ProjectDAO();
         Project project = projectDao.getProjectById(projectId);
         
         // Retrieve only completed items for this project using ItemDAO
         ItemDAO itemDao = new ItemDAO();
         List<Item> completedItems = itemDao.getCompletedItemsByProjectId(projectId);
         
         // Set the retrieved project and completed items as request attributes
         request.setAttribute("project", project);
         request.setAttribute("completedItems", completedItems);
         
         // Forward to completedItems.jsp
         request.getRequestDispatcher("completedItems.jsp").forward(request, response);
    }
}
