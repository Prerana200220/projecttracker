package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/completedProjects")
public class CompletedProjectsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
         ProjectDAO projectDao = new ProjectDAO();
         // This method should return projects that have at least one completed item.
         List<Project> completedProjects = projectDao.getCompletedProjects();
         request.setAttribute("completedProjects", completedProjects);
         request.getRequestDispatcher("completedProjects.jsp").forward(request, response);
    }
}
