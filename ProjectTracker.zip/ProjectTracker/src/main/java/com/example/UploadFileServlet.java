package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

@WebServlet("/uploadFileServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB threshold
    maxFileSize = 1024 * 1024 * 10,         // 10MB maximum
    maxRequestSize = 1024 * 1024 * 50       // 50MB overall request size
)
public class UploadFileServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Debug: log that the servlet is invoked
        System.out.println("UploadFileServlet invoked");

        // 1) Get the uploaded file (make sure your file input field is named "file")
        Part filePart = request.getPart("file");
        if (filePart == null) {
            System.out.println("No file part found");
            response.getWriter().println("Error: File part is missing.");
            return;
        }
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        System.out.println("Uploaded file name: " + fileName);

        // 2) Build the absolute path to the "uploads" folder in your web app
        String applicationPath = getServletContext().getRealPath("");
        String uploadPath = applicationPath + File.separator + "uploads";
        System.out.println("Upload path: " + uploadPath);

        // 3) Create the "uploads" directory if it doesn't exist
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            boolean dirCreated = uploadDir.mkdirs();
            System.out.println("Uploads directory created: " + dirCreated);
        }

        // 4) Write the file to the uploads directory
        String filePath = uploadPath + File.separator + fileName;
        try {
            filePart.write(filePath);
            System.out.println("File written to: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error writing file: " + e.getMessage());
            return;
        }

        // 5) Update the project record with the file name.
        // Retrieve the projectId from the form.
        String projectId = request.getParameter("projectId");
        try {
            ProjectDAO projectDao = new ProjectDAO();
            projectDao.updateFileName(projectId, fileName);
            System.out.println("Database updated with file name for project: " + projectId);
        } catch (Exception e) {
            e.printStackTrace();
            // Optionally set an error message.
        }

        // 6) Redirect back to the dashboard page so the updated file appears.
        response.sendRedirect(request.getContextPath() + "/dashboard");
    }
}
