package com.example;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class AppContextListener implements ServletContextListener {
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        //DatabaseConnection.deregisterDrivers();
        System.out.println("Database drivers deregistered.");
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Application started.");
    }
}
