package com.example;

import java.sql.Date;
import java.util.List;

public class Project {
    private int id;
    private String jobNo;
    private String customer;
    private String city;
    private String region;
    private String segment;
    private String projectManager;
    private String projectName;
    private long projectValue; // Stored in INR
    private String currency;   // Original currency (e.g., INR, USD, UKP)
    private String status;
    private String fileName;
    
    // New fields for Payment Terms and Customer Required Date
    private String paymentTerms;
    private Date customerRequiredDate;
    
    // New field for associated items
    private List<Item> items;

    // Default constructor
    public Project() {}

    // Parameterized constructor including new fields
    public Project(int id, String jobNo, String customer, String city,
                   String region, String segment, String projectManager,
                   String projectName, long projectValue, String currency, 
                   String status, String fileName, String paymentTerms, Date customerRequiredDate,
                   List<Item> items) {
        this.id = id;
        this.jobNo = jobNo;
        this.customer = customer;
        this.city = city;
        this.region = region;
        this.segment = segment;
        this.projectManager = projectManager;
        this.projectName = projectName;
        this.projectValue = projectValue;
        this.currency = currency;
        this.status = status;
        this.fileName = fileName;
        this.paymentTerms = paymentTerms;
        this.customerRequiredDate = customerRequiredDate;
        this.items = items;
    }

    // Getters and setters for project fields
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getJobNo() {
        return jobNo;
    }
    public void setJobNo(String jobNo) {
        this.jobNo = jobNo;
    }

    public String getCustomer() {
        return customer;
    }
    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }

    public String getRegion() {
        return region;
    }
    public void setRegion(String region) {
        this.region = region;
    }

    public String getSegment() {
        return segment;
    }
    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getProjectManager() {
        return projectManager;
    }
    public void setProjectManager(String projectManager) {
        this.projectManager = projectManager;
    }

    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public long getProjectValue() {
        return projectValue;
    }
    public void setProjectValue(long projectValue) {
        this.projectValue = projectValue;
    }

    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }
    public void setPaymentTerms(String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public Date getCustomerRequiredDate() {
        return customerRequiredDate;
    }
    public void setCustomerRequiredDate(Date customerRequiredDate) {
        this.customerRequiredDate = customerRequiredDate;
    }

    // Getter and setter for associated items
    public List<Item> getItems() {
        return items;
    }
    public void setItems(List<Item> items) {
        this.items = items;
    }
}
