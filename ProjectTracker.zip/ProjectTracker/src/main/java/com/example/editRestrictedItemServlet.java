package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/editRestrictedItem")
public class editRestrictedItemServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve itemId and projectId from URL parameters
        String itemIdParam = request.getParameter("itemId");
        String projectIdParam = request.getParameter("projectId");
        int itemId, projectId;
        try {
            itemId = Integer.parseInt(itemIdParam);
            projectId = Integer.parseInt(projectIdParam);
        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid item or project ID.");
            return;
        }
        
        // Retrieve the item using your DAO
        ItemDAO dao = new ItemDAO();
        Item item = dao.getItemById(itemId);
        if (item == null) {
            response.getWriter().println("Item not found.");
            return;
        }
        
        // Set attributes so the JSP can display the item details
        request.setAttribute("item", item);
        request.setAttribute("projectId", projectId);
        
        // Forward the request to editRestrictedItem.jsp (located in webapp)
        request.getRequestDispatcher("/editRestrictedItem.jsp").forward(request, response);
    }
}
