package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SendResetLinkServlet")
public class SendResetLinkServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String email = request.getParameter("email");

        try {
            // Database Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project_tracker", "root", "Root@123");

            // Check if email exists in database using correct column name (e.g., user_email)
            String sql = "SELECT * FROM users WHERE user_email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Generate reset token
                String token = UUID.randomUUID().toString();

                // Store token in database using the correct column name
                sql = "UPDATE users SET reset_token=? WHERE user_email=?";
                ps = con.prepareStatement(sql);
                ps.setString(1, token);
                ps.setString(2, email);
                ps.executeUpdate();

                // Send email with reset link
                String resetLink = "http://localhost:8080/project_tracker/resetPassword.jsp?token=" + token;
                String subject = "Password Reset Request";
                String body = "Click the link below to reset your password:\n" + resetLink;

                SendEmail.sendEmail(email, subject, body);
                response.getWriter().println("Reset link sent successfully.");
            } else {
                response.getWriter().println("Email not found.");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
