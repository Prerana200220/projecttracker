package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/addItems")
public class AddItemsServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Retrieve arrays from the form, INCLUDING srNo[]
        String[] srNos = request.getParameterValues("srNo[]");
        String[] erpNos = request.getParameterValues("erpNo[]");
        String[] itemDescriptions = request.getParameterValues("itemDescription[]");
        String[] capacities = request.getParameterValues("capacity[]");
        String[] qtys = request.getParameterValues("qty[]");
        String[] unitValues = request.getParameterValues("unitValue[]");
        String[] totalValues = request.getParameterValues("totalValue[]");
        String[] responsibilities = request.getParameterValues("responsibility[]");
        String[] plannedDates = request.getParameterValues("plannedDate[]");
        String[] completedDates = request.getParameterValues("completedDate[]");

        // 2. Parse projectId
        String projectIdStr = request.getParameter("projectId");
        int projectId = Integer.parseInt(projectIdStr);

        // 3. Prepare
        boolean allSaved = true;
        int n = (erpNos != null) ? erpNos.length : 0;
        ItemDAO itemDao = new ItemDAO();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        // 4. Loop through form rows
        for(int i = 0; i < n; i++) {
            // Basic validation: only process if ERP No is not empty
            if(erpNos[i] != null && !erpNos[i].trim().isEmpty()) {

                // Parse numeric fields
                int qty = Integer.parseInt(qtys[i]);
                double unitVal = Double.parseDouble(unitValues[i].replaceAll(",", ""));
                double totalVal = Double.parseDouble(totalValues[i].replaceAll(",", ""));

                // Parse dates
                Date plannedDate = null;
                Date completedDate = null;
                try {
                    if(plannedDates[i] != null && !plannedDates[i].trim().isEmpty()) {
                        plannedDate = sdf.parse(plannedDates[i]);
                    }
                    if(completedDates[i] != null && !completedDates[i].trim().isEmpty()) {
                        completedDate = sdf.parse(completedDates[i]);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // 5. Build the Item object
                Item item = new Item();
                item.setProjectId(projectId);

                // Set srNo from srNos array
                // Make sure your JSP has <input type="text" name="srNo[]" />
                if(srNos != null && srNos[i] != null) {
                    item.setSrNo(srNos[i]);
                } else {
                    item.setSrNo(null);
                }

                // Set the other fields
                item.setErpNo(erpNos[i]);
                item.setItemDescription(itemDescriptions[i]);
                item.setCapacity(capacities[i]);
                item.setQty(qty);
                item.setUnitValue(unitVal);
                item.setTotalValue(totalVal);
                item.setResponsibility(responsibilities[i]);
                item.setPlannedDate(plannedDate);
                item.setCompletedDate(completedDate);

                // 6. Save the item
                boolean saved = itemDao.addItem(item);
                if(!saved) {
                    allSaved = false;
                }
            }
        }

        // 7. Redirect or show error
        if(allSaved) {
            response.sendRedirect("viewItems?projectId=" + projectId);
        } else {
            response.getWriter().println("<h3>Error saving some items.</h3>");
        }
    }
}
