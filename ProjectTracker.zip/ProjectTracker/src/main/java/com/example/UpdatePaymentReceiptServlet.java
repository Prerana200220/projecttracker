package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

@WebServlet("/UpdatePaymentReceiptServlet")
public class UpdatePaymentReceiptServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve parameters from the form submission
        String receiptIdParam = request.getParameter("receiptId");
        String projectIdParam = request.getParameter("projectId");
        String projectName = request.getParameter("projectName");
        String paymentPhase = request.getParameter("paymentPhase");
        String amountParam = request.getParameter("amount");
        String mode = request.getParameter("mode");
        String paymentDate = request.getParameter("paymentDate");
        String remarks = request.getParameter("remarks");
        
        // Parse numeric values
        int receiptId = Integer.parseInt(receiptIdParam);
        int projectId = Integer.parseInt(projectIdParam);
        double amount = Double.parseDouble(amountParam);
        
        // Create a PaymentReceipt object and set its fields
        PaymentReceipt receipt = new PaymentReceipt();
        receipt.setId(receiptId);
        receipt.setProjectId(projectId);
        receipt.setPaymentPhase(paymentPhase);
        receipt.setAmount(amount);
        receipt.setMode(mode);
        receipt.setPaymentDate(paymentDate);
        receipt.setRemarks(remarks);
        
        // Update the receipt using DAO
        PaymentReceiptDAO dao = new PaymentReceiptDAO();
        boolean updated = dao.updatePaymentReceipt(receipt);
        
        // Redirect back to the payment phase page with a success/error message
        String encodedProjectName = URLEncoder.encode(projectName, "UTF-8");
        if(updated) {
            response.sendRedirect("paymentphase.jsp?projectId=" + projectIdParam 
                + "&projectName=" + encodedProjectName + "&message=success");
        } else {
            response.sendRedirect("paymentphase.jsp?projectId=" + projectIdParam 
                + "&projectName=" + encodedProjectName + "&message=error");
        }
    }
}
