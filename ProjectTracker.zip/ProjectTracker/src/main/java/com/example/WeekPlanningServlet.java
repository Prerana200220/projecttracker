package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/weekPlanning")
public class WeekPlanningServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProjectDAO projectDao = new ProjectDAO();
        List<Project> projects = projectDao.getAllProjectsWithItems();
        request.setAttribute("projects", projects);

        // Get the "type" parameter to determine which JSP to load
        String reportType = request.getParameter("type");

        if ("projectwise".equals(reportType)) {
            request.getRequestDispatcher("weekPlanning1.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("weekPlanning.jsp").forward(request, response);
        }
    }
}
