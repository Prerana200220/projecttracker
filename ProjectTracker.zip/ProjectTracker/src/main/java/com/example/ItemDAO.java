package com.example;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    // Retrieves all items for a given project.
    public List<Item> getItemsForProject(int projectId) {
        List<Item> list = new ArrayList<>();
        String sql = "SELECT * FROM items WHERE project_id = ?";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/project_tracker", "root", "Root@123");
                 PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, projectId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Item item = new Item();
                        item.setId(rs.getInt("id"));
                        item.setProjectId(rs.getInt("project_id"));
                        item.setErpNo(rs.getString("erpNo"));
                        item.setItemDescription(rs.getString("item_description"));
                        item.setCapacity(rs.getString("capacity"));
                        item.setQty(rs.getInt("qty"));
                        item.setUnitValue(rs.getDouble("unit_value"));
                        item.setTotalValue(rs.getDouble("total_value"));
                        item.setResponsibility(rs.getString("responsibility"));
                        item.setDelayReason(rs.getString("delay_reason"));

                        Date planDate = rs.getDate("planned_date");
                        if (planDate != null) {
                            item.setPlannedDate(new java.util.Date(planDate.getTime()));
                        }
                        Date compDate = rs.getDate("completed_date");
                        if (compDate != null) {
                            item.setCompletedDate(new java.util.Date(compDate.getTime()));
                        }
                        item.setStatus(rs.getString("status"));
                        Date readyByDate = rs.getDate("ready_by");
                        if (readyByDate != null) {
                            item.setReadyBy(new java.util.Date(readyByDate.getTime()));
                        }
                        list.add(item);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    // Sets the completed date for an item.
    public void setItemCompleted(int itemId, java.util.Date completedDate) {
        String sql = "UPDATE items SET completed_date=? WHERE id=?";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/project_tracker", "root", "Root@123");
                 PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setDate(1, new Date(completedDate.getTime()));
                ps.setInt(2, itemId);
                ps.executeUpdate();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Adds a new item to the database.
    public boolean addItem(Item item) {
        String sql = "INSERT INTO items (project_id, srNo, erpNo, item_description, capacity, qty, unit_value, responsibility, planned_date, completed_date) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, item.getProjectId());
            stmt.setString(2, item.getSrNo());
            stmt.setString(3, item.getErpNo());
            stmt.setString(4, item.getItemDescription());
            stmt.setString(5, item.getCapacity());
            stmt.setInt(6, item.getQty());
            stmt.setDouble(7, item.getUnitValue());

            // Check responsibility: if empty, set to NULL
            String responsibility = item.getResponsibility();
            if (responsibility == null || responsibility.trim().isEmpty()) {
                stmt.setNull(8, Types.VARCHAR);
            } else {
                stmt.setString(8, responsibility);
            }

            if (item.getPlannedDate() != null) {
                stmt.setDate(9, new java.sql.Date(item.getPlannedDate().getTime()));
            } else {
                stmt.setNull(9, Types.DATE);
            }

            if (item.getCompletedDate() != null) {
                stmt.setDate(10, new java.sql.Date(item.getCompletedDate().getTime()));
            } else {
                stmt.setNull(10, Types.DATE);
            }

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Updates an existing item with full details.
    public boolean updateItem(Item item) {
        String sql = "UPDATE items SET srNo = ?, erpNo = ?, item_description = ?, capacity = ?, qty = ?, unit_value = ?, "
                   + "responsibility = ?, planned_date = ?, completed_date = ?, delay_reason = ?, status = ?, ready_by = ? "
                   + "WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, item.getSrNo());
            stmt.setString(2, item.getErpNo());
            stmt.setString(3, item.getItemDescription());
            stmt.setString(4, item.getCapacity());
            stmt.setInt(5, item.getQty());
            stmt.setDouble(6, item.getUnitValue());

            // Check responsibility: if empty, set to NULL
            String responsibility = item.getResponsibility();
            if (responsibility == null || responsibility.trim().isEmpty()) {
                stmt.setNull(7, Types.VARCHAR);
            } else {
                stmt.setString(7, responsibility);
            }

            if (item.getPlannedDate() != null) {
                stmt.setDate(8, new java.sql.Date(item.getPlannedDate().getTime()));
            } else {
                stmt.setNull(8, Types.DATE);
            }
            if (item.getCompletedDate() != null) {
                stmt.setDate(9, new java.sql.Date(item.getCompletedDate().getTime()));
            } else {
                stmt.setNull(9, Types.DATE);
            }
            if (item.getDelayReason() != null && !item.getDelayReason().trim().isEmpty()) {
                stmt.setString(10, item.getDelayReason());
            } else {
                stmt.setNull(10, Types.VARCHAR);
            }
            if (item.getStatus() != null && !item.getStatus().trim().isEmpty()) {
                stmt.setString(11, item.getStatus());
            } else {
                stmt.setNull(11, Types.VARCHAR);
            }
            if (item.getReadyBy() != null) {
                stmt.setDate(12, new java.sql.Date(item.getReadyBy().getTime()));
            } else {
                stmt.setNull(12, Types.DATE);
            }
            stmt.setInt(13, item.getId());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Retrieves completed items for a given project.
    public List<Item> getCompletedItemsByProjectId(int projectId) {
        List<Item> items = new ArrayList<>();
        String sql = "SELECT * FROM items WHERE project_id = ? AND completed_date IS NOT NULL";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, projectId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Item item = new Item();
                    item.setSrNo(rs.getString("srNo"));
                    item.setId(rs.getInt("id"));
                    item.setProjectId(rs.getInt("project_id"));
                    item.setErpNo(rs.getString("erpNo"));
                    item.setItemDescription(rs.getString("item_description"));
                    item.setCapacity(rs.getString("capacity"));
                    item.setQty(rs.getInt("qty"));
                    item.setUnitValue(rs.getDouble("unit_value"));
                    item.setTotalValue(rs.getDouble("total_value"));
                    item.setResponsibility(rs.getString("responsibility"));
                    
                    Date planDate = rs.getDate("planned_date");
                    if (planDate != null) {
                        item.setPlannedDate(new java.util.Date(planDate.getTime()));
                    }
                    Date compDate = rs.getDate("completed_date");
                    if (compDate != null) {
                        item.setCompletedDate(new java.util.Date(compDate.getTime()));
                    }
                    item.setDelayReason(rs.getString("delay_reason"));
                    item.setStatus(rs.getString("status"));
                    Date readyByDate = rs.getDate("ready_by");
                    if (readyByDate != null) {
                        item.setReadyBy(new java.util.Date(readyByDate.getTime()));
                    }
                    items.add(item);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return items;
    }

    // Retrieves a single item by its ID.
    public Item getItemById(int itemId) {
        String sql = "SELECT * FROM items WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, itemId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Item item = new Item();
                    item.setSrNo(rs.getString("srNo"));
                    item.setId(rs.getInt("id"));
                    item.setProjectId(rs.getInt("project_id"));
                    item.setErpNo(rs.getString("erpNo"));
                    item.setItemDescription(rs.getString("item_description"));
                    item.setCapacity(rs.getString("capacity"));
                    item.setQty(rs.getInt("qty"));
                    item.setUnitValue(rs.getDouble("unit_value"));
                    item.setResponsibility(rs.getString("responsibility"));
                    
                    Date planDate = rs.getDate("planned_date");
                    if (planDate != null) {
                        item.setPlannedDate(new java.util.Date(planDate.getTime()));
                    }
                    Date compDate = rs.getDate("completed_date");
                    if (compDate != null) {
                        item.setCompletedDate(new java.util.Date(compDate.getTime()));
                    }
                    item.setDelayReason(rs.getString("delay_reason"));
                    item.setStatus(rs.getString("status"));
                    Date readyByDate = rs.getDate("ready_by");
                    if (readyByDate != null) {
                        item.setReadyBy(new java.util.Date(readyByDate.getTime()));
                    }
                    return item;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    // Updates restricted fields (status and ready_by) for an item.
    public boolean updateRestrictedItem(Item item) {
        String sql = "UPDATE items SET status = ?, ready_by = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, item.getStatus());
            if (item.getReadyBy() != null) {
                ps.setDate(2, new Date(item.getReadyBy().getTime()));
            } else {
                ps.setNull(2, Types.DATE);
            }
            ps.setInt(3, item.getId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Deletes an item by its ID.
    public boolean deleteItem(int itemId) {
        String sql = "DELETE FROM items WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, itemId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Retrieves items for a project.
    public List<Item> getItemsByProjectId(int projectId) {
        List<Item> items = new ArrayList<>();
        String sql = "SELECT * FROM items WHERE project_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, projectId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Item item = new Item();
                    item.setSrNo(rs.getString("srNo"));
                    item.setId(rs.getInt("id"));
                    item.setProjectId(rs.getInt("project_id"));
                    item.setErpNo(rs.getString("erpNo"));
                    item.setItemDescription(rs.getString("item_description"));
                    item.setCapacity(rs.getString("capacity"));
                    item.setQty(rs.getInt("qty"));
                    item.setUnitValue(rs.getDouble("unit_value"));
                    item.setTotalValue(rs.getDouble("total_value"));
                    item.setResponsibility(rs.getString("responsibility"));
                    item.setPlannedDate(rs.getDate("planned_date"));
                    item.setCompletedDate(rs.getDate("completed_date"));
                    item.setDelayReason(rs.getString("delay_reason"));
                    item.setStatus(rs.getString("status"));
                    item.setReadyBy(rs.getDate("ready_by"));
                    
                    items.add(item);
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return items;
    }
}
