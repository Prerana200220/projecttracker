package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PaymentReceiptDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/project_tracker"; // change as needed
    private String jdbcUsername = "root"; // change as needed
    private String jdbcPassword = "Root@123"; // change as needed

    private static final String INSERT_PAYMENT_SQL = 
        "INSERT INTO payment_receipts (project_id, payment_phase, amount, mode, payment_date, remarks,percentage) VALUES (?, ?, ?, ?, ?, ?,?)";
    
    private static final String SELECT_PAYMENTS_BY_PROJECT = 
        "SELECT * FROM payment_receipts WHERE project_id = ?";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    // Insert a new payment record
    public boolean insertPayment(PaymentReceipt receipt) {
        boolean rowInserted = false;
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(INSERT_PAYMENT_SQL)) {
            
            ps.setInt(1, receipt.getProjectId());
            ps.setString(2, receipt.getPaymentPhase());
            ps.setDouble(3, receipt.getAmount());
            ps.setString(4, receipt.getMode());
            ps.setString(5, receipt.getPaymentDate());
            ps.setString(6, receipt.getRemarks());
            ps.setString(7, receipt.getPercentage()); // new column
            
            rowInserted = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowInserted;
    }

    // Retrieve payments for a given project
    public List<PaymentReceipt> getPaymentsByProject(int projectId) {
        List<PaymentReceipt> payments = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_PAYMENTS_BY_PROJECT)) {
            ps.setInt(1, projectId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                PaymentReceipt receipt = new PaymentReceipt();
                receipt.setId(rs.getInt("id"));
                receipt.setProjectId(rs.getInt("project_id"));
                receipt.setPaymentPhase(rs.getString("payment_phase"));
                receipt.setAmount(rs.getDouble("amount"));
                receipt.setMode(rs.getString("mode"));
                receipt.setPaymentDate(rs.getString("payment_date"));
                receipt.setRemarks(rs.getString("remarks"));
                receipt.setPercentage(rs.getString("percentage")); // new column
                payments.add(receipt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return payments;
    }
    public boolean deletePaymentReceipt(int receiptId) {
        boolean rowDeleted = false;
        String sql = "DELETE FROM payment_receipts WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, receiptId);
            rowDeleted = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }

    public PaymentReceipt getPaymentReceiptById(int receiptId) {
        PaymentReceipt receipt = null;
        String sql = "SELECT * FROM payment_receipts WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, receiptId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                receipt = new PaymentReceipt();
                receipt.setId(rs.getInt("id"));
                receipt.setProjectId(rs.getInt("project_id"));
                receipt.setPaymentPhase(rs.getString("payment_phase"));
                receipt.setAmount(rs.getDouble("amount"));
                receipt.setMode(rs.getString("mode"));
                receipt.setPaymentDate(rs.getString("payment_date"));
                receipt.setRemarks(rs.getString("remarks"));
                receipt.setPercentage(rs.getString("percentage")); // new column
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return receipt;
    }


    
    public boolean updatePaymentReceipt(PaymentReceipt receipt) {
        boolean rowUpdated = false;
        String sql = "UPDATE payment_receipts SET payment_phase = ?, amount = ?, mode = ?, payment_date = ?, remarks = ? ,percentage = ? WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, receipt.getPaymentPhase());
            ps.setDouble(2, receipt.getAmount());
            ps.setString(3, receipt.getMode());
            ps.setString(4, receipt.getPaymentDate());
            ps.setString(5, receipt.getRemarks());
            ps.setString(7, receipt.getPercentage()); // new column
            ps.setInt(6, receipt.getId());
            rowUpdated = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }

}
