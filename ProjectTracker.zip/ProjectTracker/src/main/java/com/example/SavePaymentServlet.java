package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

@WebServlet("/SavePaymentServlet")
public class SavePaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve form parameters
        String projectIdParam = request.getParameter("projectId");
        String projectName = request.getParameter("projectName");
        String paymentPhase = request.getParameter("paymentPhase");
        String amountParam = request.getParameter("amount");
        String mode = request.getParameter("mode");
        String paymentDate = request.getParameter("paymentDate");
        String remarks = request.getParameter("remarks");
        String percentage = request.getParameter("percentage");

        // Parse numeric values
        int projectId = Integer.parseInt(projectIdParam);
        // Remove any commas from the amount string before parsing to double
        amountParam = amountParam.replace(",", "");
        double amount = Double.parseDouble(amountParam);

        // Create a PaymentReceipt object and set its fields
        PaymentReceipt receipt = new PaymentReceipt();
        receipt.setProjectId(projectId);
        receipt.setPaymentPhase(paymentPhase);
        receipt.setAmount(amount);
        receipt.setMode(mode);
        receipt.setPaymentDate(paymentDate);
        receipt.setRemarks(remarks);
        receipt.setPercentage(percentage);


        // Insert into the database using DAO
        PaymentReceiptDAO dao = new PaymentReceiptDAO();
        boolean success = dao.insertPayment(receipt);

        // Build redirect URL
        // NOTE: We must include both projectId AND projectName so receipt_of_payment.jsp doesn't show an error
        String encodedProjectName = URLEncoder.encode(projectName, "UTF-8");
        String redirectURL = "receipt_of_payment.jsp?projectId=" + projectId
                           + "&projectName=" + encodedProjectName;

        if (success) {
            // Add success message
            redirectURL += "&message=success";
        } else {
            // Add error message
            redirectURL += "&message=error";
        }

        // Redirect back to receipt_of_payment.jsp
        response.sendRedirect(redirectURL);
    }
}
