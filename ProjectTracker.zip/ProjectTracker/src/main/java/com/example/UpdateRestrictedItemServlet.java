package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/updateRestrictedItem")
public class UpdateRestrictedItemServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String role = (String) session.getAttribute("userRole");
        if (role == null) {
            role = "user";
        }
        
        int itemId = Integer.parseInt(request.getParameter("itemId"));
        int projectId = Integer.parseInt(request.getParameter("projectId"));
        String status = request.getParameter("status");
        String readyByStr = request.getParameter("readyBy");
        Date readyBy = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            if (readyByStr != null && !readyByStr.trim().isEmpty()) {
                readyBy = sdf.parse(readyByStr.trim());
            }
            
            // Retrieve the item from the database to check filtering
            ItemDAO dao = new ItemDAO();
            Item item = dao.getItemById(itemId);
            
            // Filtering check: ensure the item matches allowed responsibilities for the role
            boolean allowed = false;
            if (role.equalsIgnoreCase("unit1")) {
                if (item.getResponsibility() != null &&
                    item.getResponsibility().equalsIgnoreCase("Unit1")) {
                    allowed = true;
                }
            } else if (role.equalsIgnoreCase("unit2")) {
                if (item.getResponsibility() != null &&
                    item.getResponsibility().equalsIgnoreCase("Unit2")) {
                    allowed = true;
                }
            } else if (role.equalsIgnoreCase("purchase") || role.equalsIgnoreCase("purchases")) {
                if (item.getResponsibility() != null &&
                   (item.getResponsibility().equalsIgnoreCase("Bought Out") ||
                    item.getResponsibility().equalsIgnoreCase("Import"))) {
                    allowed = true;
                }
            }
            
            if (!allowed) {
                response.getWriter().println("You are not authorized to update this item.");
                return;
            }
            
            // Update only the allowed fields: Status and Ready By
            item.setStatus(status);
            item.setReadyBy(readyBy);
            
            // Call the DAO update method (which should update only the restricted columns)
            boolean updated = dao.updateRestrictedItem(item);
            if (updated) {
                response.sendRedirect("viewItems?projectId=" + projectId);
            } else {
                response.getWriter().println("Error updating the item.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Exception: " + e.getMessage());
        }
    }
}
