package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/deleteItem")
public class DeleteItemServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Retrieve parameters from the request.
            int itemId = Integer.parseInt(request.getParameter("itemId"));
            int projectId = Integer.parseInt(request.getParameter("projectId"));

            // Call the DAO method to delete the item.
            ItemDAO itemDao = new ItemDAO();
            boolean deleted = itemDao.deleteItem(itemId);

            // If deletion was successful, redirect to viewItems page.
            if (deleted) {
                response.sendRedirect("viewItems?projectId=" + projectId);
            } else {
                response.getWriter().println("<h3>Error deleting item.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Exception: " + e.getMessage() + "</h3>");
        }
    }
}
