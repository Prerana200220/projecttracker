package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/saveItem")
public class SaveItemServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int itemId = Integer.parseInt(request.getParameter("itemId"));
            int projectId = Integer.parseInt(request.getParameter("projectId"));
            String erpNo = request.getParameter("erpNo");
            String itemDescription = request.getParameter("itemDescription");
            String capacity = request.getParameter("capacity");
            int qty = Integer.parseInt(request.getParameter("qty"));
            double unitValue = Double.parseDouble(request.getParameter("unitValue"));
            String responsibility = request.getParameter("responsibility");
            String plannedDateStr = request.getParameter("plannedDate");
            String completedDateStr = request.getParameter("completedDate");

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date plannedDate = null;
            Date completedDate = null;
            if (plannedDateStr != null && !plannedDateStr.trim().isEmpty()) {
                plannedDate = sdf.parse(plannedDateStr.trim());
            }
            if (completedDateStr != null && !completedDateStr.trim().isEmpty()) {
                completedDate = sdf.parse(completedDateStr.trim());
            }

            // Create an Item object with the updated values.
            Item item = new Item();
            item.setId(itemId);
            item.setErpNo(erpNo);
            item.setItemDescription(itemDescription);
            item.setCapacity(capacity);
            item.setQty(qty);
            item.setUnitValue(unitValue);
            item.setResponsibility(responsibility);
            item.setPlannedDate(plannedDate);
            item.setCompletedDate(completedDate);

            // Update the item using the DAO.
            ItemDAO itemDao = new ItemDAO();
            boolean updated = itemDao.updateItem(item);
            if (updated) {
                response.getWriter().print("Successfully updated item.");
            } else {
                response.getWriter().print("Error updating item.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().print("Exception: " + e.getMessage());
        }
    }
}
