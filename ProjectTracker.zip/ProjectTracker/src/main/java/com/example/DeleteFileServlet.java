package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;

@WebServlet("/deleteFile")
public class DeleteFileServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get projectId parameter.
        String projectId = request.getParameter("projectId");
        // Get file name parameter.
        String fileName = request.getParameter("fileName");
        
        // Build the absolute path to your "uploads" folder.
        String applicationPath = getServletContext().getRealPath("");
        String uploadPath = applicationPath + File.separator + "uploads";
        File file = new File(uploadPath + File.separator + fileName);
        
        if (file.exists()) {
            if(file.delete()){
                // Update the project's fileName in the database.
                ProjectDAO projectDao = new ProjectDAO();
                projectDao.updateFileName(projectId, "");
            }
        }
        // Redirect back to dashboard (or use request.getHeader("Referer"))
        response.sendRedirect(request.getContextPath() + "/dashboard");
    }
}
