package com.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjectDAO {

    // Inserts a new project.
    public boolean addProject(Project project) {
        String sql = "INSERT INTO projects (job_no, customer, city, region, segment, project_manager, project_name, project_value, currency, payment_terms, customer_required_date) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, project.getJobNo());
            stmt.setString(2, project.getCustomer());
            stmt.setString(3, project.getCity());
            stmt.setString(4, project.getRegion());
            stmt.setString(5, project.getSegment());
            stmt.setString(6, project.getProjectManager());
            stmt.setString(7, project.getProjectName());
            stmt.setLong(8, project.getProjectValue());
            stmt.setString(9, project.getCurrency());
            stmt.setString(10, project.getPaymentTerms());
            stmt.setDate(11, project.getCustomerRequiredDate());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Inserts a new project and returns its generated ID.
    public int addProjectAndReturnId(Project project) {
        int generatedId = -1;
        String sql = "INSERT INTO projects (job_no, customer, city, region, segment, project_manager, project_name, project_value, currency, payment_terms, customer_required_date) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
             
            stmt.setString(1, project.getJobNo());
            stmt.setString(2, project.getCustomer());
            stmt.setString(3, project.getCity());
            stmt.setString(4, project.getRegion());
            stmt.setString(5, project.getSegment());
            stmt.setString(6, project.getProjectManager());
            stmt.setString(7, project.getProjectName());
            stmt.setLong(8, project.getProjectValue());
            stmt.setString(9, project.getCurrency());
            stmt.setString(10, project.getPaymentTerms());
            stmt.setDate(11, project.getCustomerRequiredDate());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedId = rs.getInt(1);
                    }
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return generatedId;
    }
    
    // Retrieves all projects (without their items) using an optional search filter.
    public List<Project> getProjects(String search) {
        List<Project> projects = new ArrayList<>();
        boolean hasSearch = (search != null && !search.trim().isEmpty());
        String sql = "SELECT * FROM projects";
        if (hasSearch) {
            sql += " WHERE job_no LIKE ? OR customer LIKE ? OR city LIKE ? OR region LIKE ? " +
                   "OR segment LIKE ? OR project_manager LIKE ? OR project_name LIKE ? OR currency LIKE ?";
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            if (hasSearch) {
                String wildcard = "%" + search + "%";
                for (int i = 1; i <= 8; i++) {
                    stmt.setString(i, wildcard);
                }
            }
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Project p = new Project();
                    p.setId(rs.getInt("id"));
                    p.setJobNo(rs.getString("job_no"));
                    p.setCustomer(rs.getString("customer"));
                    p.setCity(rs.getString("city"));
                    p.setRegion(rs.getString("region"));
                    p.setSegment(rs.getString("segment"));
                    p.setProjectManager(rs.getString("project_manager"));
                    p.setProjectName(rs.getString("project_name"));
                    p.setProjectValue(rs.getLong("project_value"));
                    p.setCurrency(rs.getString("currency"));
                    p.setFileName(rs.getString("fileName"));
                    // Set new fields
                    p.setPaymentTerms(rs.getString("payment_terms"));
                    p.setCustomerRequiredDate(rs.getDate("customer_required_date"));
                    projects.add(p);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return projects;
    }
    
    // Retrieves all projects and loads each project's associated items.
    public List<Project> getAllProjectsWithItems() {
        List<Project> projects = getProjects(null);
        ItemDAO itemDao = new ItemDAO();
        for (Project proj : projects) {
            List<Item> items = itemDao.getItemsByProjectId(proj.getId());
            proj.setItems(items);
        }
        return projects;
    }
    
    // Retrieves projects filtered by a specific field.
    public List<Project> getFilteredProjects(String field, String value) {
        List<Project> projects = new ArrayList<>();
        String sql = "SELECT * FROM projects WHERE ";
        switch(field) {
            case "customer":
                sql += "customer LIKE ?";
                break;
            case "region":
                sql += "region LIKE ?";
                break;
            case "segment":
                sql += "segment LIKE ?";
                break;
            case "projectManager":
                sql += "project_manager LIKE ?";
                break;
            case "projectName":
                sql += "project_name LIKE ?";
                break;
            case "currency":
                sql += "currency LIKE ?";
                break;
            case "responsibility":
                // Filtering by responsibility (project items) – joining with items table.
                sql = "SELECT DISTINCT p.* FROM projects p JOIN items i ON p.id = i.project_id WHERE i.responsibility LIKE ?";
                break;
            default:
                sql += "1=1"; // No filtering if field is not recognized.
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, "%" + value + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Project p = new Project();
                    p.setId(rs.getInt("id"));
                    p.setJobNo(rs.getString("job_no"));
                    p.setCustomer(rs.getString("customer"));
                    p.setCity(rs.getString("city"));
                    p.setRegion(rs.getString("region"));
                    p.setSegment(rs.getString("segment"));
                    p.setProjectManager(rs.getString("project_manager"));
                    p.setProjectName(rs.getString("project_name"));
                    p.setProjectValue(rs.getLong("project_value"));
                    p.setCurrency(rs.getString("currency"));
                    p.setFileName(rs.getString("fileName"));
                    // Set new fields
                    p.setPaymentTerms(rs.getString("payment_terms"));
                    p.setCustomerRequiredDate(rs.getDate("customer_required_date"));
                    projects.add(p);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return projects;
    }
    
    protected Connection getConnection() throws SQLException, ClassNotFoundException {
        return DatabaseConnection.getConnection();
    }
    
    public void updateFileName(String projectId, String fileName) {
        String sql = "UPDATE projects SET fileName = ? WHERE id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
             ps.setString(1, fileName);
             ps.setString(2, projectId);
             ps.executeUpdate();
             
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Method to get projects that have at least one completed item.
    public List<Project> getCompletedProjects() {
        List<Project> projects = new ArrayList<>();
        String sql = "SELECT DISTINCT p.* FROM projects p JOIN items i ON p.id = i.project_id WHERE i.completed_date IS NOT NULL";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
             
             while (rs.next()) {
                 Project p = new Project();
                 p.setId(rs.getInt("id"));
                 p.setJobNo(rs.getString("job_no"));
                 p.setCustomer(rs.getString("customer"));
                 p.setCity(rs.getString("city"));
                 p.setRegion(rs.getString("region"));
                 p.setSegment(rs.getString("segment"));
                 p.setProjectManager(rs.getString("project_manager"));
                 p.setProjectName(rs.getString("project_name"));
                 p.setProjectValue(rs.getLong("project_value"));
                 p.setCurrency(rs.getString("currency"));
                 p.setFileName(rs.getString("fileName"));
                 // Set new fields
                 p.setPaymentTerms(rs.getString("payment_terms"));
                 p.setCustomerRequiredDate(rs.getDate("customer_required_date"));
                 projects.add(p);
             }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return projects;
    }
  
    // Retrieves projects by filtering on the responsibility of their items.
    public List<Project> getProjectsByResponsibility(String responsibility) {
        List<Project> projects = new ArrayList<>();
        String sql = "SELECT DISTINCT p.* " +
                     "FROM projects p " +
                     "JOIN items i ON p.id = i.project_id " +
                     "WHERE i.responsibility LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, "%" + responsibility + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Project p = new Project();
                    p.setId(rs.getInt("id"));
                    p.setJobNo(rs.getString("job_no"));
                    p.setCustomer(rs.getString("customer"));
                    p.setCity(rs.getString("city"));
                    p.setRegion(rs.getString("region"));
                    p.setSegment(rs.getString("segment"));
                    p.setProjectManager(rs.getString("project_manager"));
                    p.setProjectName(rs.getString("project_name"));
                    p.setProjectValue(rs.getLong("project_value"));
                    p.setCurrency(rs.getString("currency"));
                    p.setFileName(rs.getString("fileName"));
                    // Set new fields
                    p.setPaymentTerms(rs.getString("payment_terms"));
                    p.setCustomerRequiredDate(rs.getDate("customer_required_date"));
                    projects.add(p);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return projects;
    }
    
    // Updates an existing project.
    public boolean updateProject(Project project) {
        String sql = "UPDATE projects SET job_no = ?, customer = ?, city = ?, region = ?, segment = ?, " +
                     "project_manager = ?, project_name = ?, project_value = ?, currency = ?, payment_terms = ?, customer_required_date = ? " +
                     "WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, project.getJobNo());
            stmt.setString(2, project.getCustomer());
            stmt.setString(3, project.getCity());
            stmt.setString(4, project.getRegion());
            stmt.setString(5, project.getSegment());
            stmt.setString(6, project.getProjectManager());
            stmt.setString(7, project.getProjectName());
            stmt.setLong(8, project.getProjectValue());
            stmt.setString(9, project.getCurrency());
            stmt.setString(10, project.getPaymentTerms());
            stmt.setDate(11, project.getCustomerRequiredDate());
            stmt.setInt(12, project.getId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Deletes a project by its ID.
    public boolean deleteProject(int projectId) {
        String sql = "DELETE FROM projects WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, projectId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Retrieves a project by its ID.
    public Project getProjectById(int projectId) {
        String sql = "SELECT * FROM projects WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, projectId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Project p = new Project();
                    p.setId(rs.getInt("id"));
                    p.setJobNo(rs.getString("job_no"));
                    p.setCustomer(rs.getString("customer"));
                    p.setCity(rs.getString("city"));
                    p.setRegion(rs.getString("region"));
                    p.setSegment(rs.getString("segment"));
                    p.setProjectManager(rs.getString("project_manager"));
                    p.setProjectName(rs.getString("project_name"));
                    p.setProjectValue(rs.getLong("project_value"));
                    p.setCurrency(rs.getString("currency"));
                    p.setFileName(rs.getString("fileName"));
                    // Set new fields
                    p.setPaymentTerms(rs.getString("payment_terms"));
                    p.setCustomerRequiredDate(rs.getDate("customer_required_date"));
                    return p;
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
