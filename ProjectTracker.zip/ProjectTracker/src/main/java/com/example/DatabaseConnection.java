package com.example; 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseConnection {
    // Ensure that the URL matches your server's settings
    private static final String URL = "jdbc:mysql://localhost:3306/project_tracker?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "Root@123";

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    
    // Utility method to close ResultSet, PreparedStatement, and Connection
    public static void close(ResultSet rs, PreparedStatement ps, Connection conn) {
        try { if (rs != null) rs.close(); } catch(Exception e) { e.printStackTrace(); }
        try { if (ps != null) ps.close(); } catch(Exception e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch(Exception e) { e.printStackTrace(); }
    }
}
