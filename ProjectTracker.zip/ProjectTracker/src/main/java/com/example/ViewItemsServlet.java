package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

//@WebServlet("/viewItems")
public class ViewItemsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String projectIdStr = request.getParameter("projectId");

        if (projectIdStr == null || projectIdStr.isEmpty()) {
            response.getWriter().println("<h3>Error: Project ID not provided!</h3>");
            return;
        }

        try {
            int projectId = Integer.parseInt(projectIdStr);
            System.out.println("Received projectId: " + projectId); // Debug log

            ProjectDAO projectDao = new ProjectDAO();
            Project project = projectDao.getProjectById(projectId);

            if (project != null) {
                // Fetch associated items
                ItemDAO itemDao = new ItemDAO();
                List<Item> items = itemDao.getItemsByProjectId(projectId);

                System.out.println("Project found: " + project.getProjectName());
                System.out.println("Items found: " + (items != null ? items.size() : 0));

                // Set attributes and forward to JSP
                request.setAttribute("project", project);
                request.setAttribute("items", items);
                request.getRequestDispatcher("/viewItems.jsp").forward(request, response);
            } else {
                response.getWriter().println("<h3>Error: Project not found!</h3>");
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid project ID format: " + projectIdStr);
            response.getWriter().println("<h3>Error: Invalid project ID format!</h3>");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Error: Something went wrong!</h3>");
        }
    }
}
