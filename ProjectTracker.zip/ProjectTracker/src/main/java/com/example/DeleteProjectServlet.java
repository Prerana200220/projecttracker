package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

//@WebServlet("/deleteProject")
public class DeleteProjectServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String projectIdStr = request.getParameter("projectId");
        if (projectIdStr != null) {
            try {
                int projectId = Integer.parseInt(projectIdStr);
                ProjectDAO dao = new ProjectDAO();
                boolean deleted = dao.deleteProject(projectId);
                if (deleted) {
                    response.sendRedirect("dashboard");
                } else {
                    response.getWriter().println("<h3>Error deleting project</h3>");
                }
            } catch (NumberFormatException e) {
                response.getWriter().println("<h3>Invalid project id</h3>");
            }
        } else {
            response.getWriter().println("<h3>No project id provided</h3>");
        }
    }
}
