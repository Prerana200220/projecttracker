package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/ResetPasswordServlet")
public class ResetPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve parameters from the form
        String token = request.getParameter("token");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");
        
        // Check that the new password and confirmation match.
        if (newPassword == null || !newPassword.equals(confirmPassword)) {
            response.getWriter().println("Passwords do not match. Please try again.");
            return;
        }
        
        // In production, ensure you hash the new password before saving it.
        try (Connection con = DatabaseConnection.getConnection()) {
            // 1. Verify the token by selecting the user
            String sql = "SELECT * FROM users WHERE reset_token = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, token);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                // 2. Update the user's password and clear the reset token.
                sql = "UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?";
                ps = con.prepareStatement(sql);
                ps.setString(1, newPassword); // Use a hashed password in production.
                ps.setString(2, token);
                int rowsAffected = ps.executeUpdate();
                
                if (rowsAffected > 0) {
                    response.getWriter().println("Password has been reset successfully. Please check it.");
                } else {
                    response.getWriter().println("Error updating password. Please try again.");
                }
            } else {
                response.getWriter().println("Invalid or expired token.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Exception: " + e.getMessage());
        }
    }
}
