package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

@WebServlet("/deletePaymentReceipt")
public class DeletePaymentReceipt extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        // Retrieve parameters from the URL
        String receiptIdParam = request.getParameter("receiptId");
        String projectIdParam = request.getParameter("projectId");
        String projectName = request.getParameter("projectName");
        
        // Basic validation: if receiptId is missing, redirect back with error
        if (receiptIdParam == null || receiptIdParam.trim().isEmpty()) {
            response.sendRedirect("paymentphase.jsp?projectId=" + projectIdParam + "&projectName=" 
                + URLEncoder.encode(projectName, "UTF-8") + "&message=error");
            return;
        }
        
        int receiptId = Integer.parseInt(receiptIdParam);
        
        // Use DAO to delete the payment receipt
        PaymentReceiptDAO dao = new PaymentReceiptDAO();
        boolean deleted = dao.deletePaymentReceipt(receiptId);
        
        // Redirect back to paymentphase.jsp with success or error message
        String encodedProjectName = URLEncoder.encode(projectName, "UTF-8");
        if(deleted) {
            response.sendRedirect("paymentphase.jsp?projectId=" + projectIdParam + "&projectName=" + encodedProjectName + "&message=success");
        } else {
            response.sendRedirect("paymentphase.jsp?projectId=" + projectIdParam + "&projectName=" + encodedProjectName + "&message=error");
        }
    }
}
