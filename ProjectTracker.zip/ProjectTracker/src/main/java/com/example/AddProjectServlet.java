package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

public class AddProjectServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Retrieve form parameters
            String jobNo = request.getParameter("jobNo");
            String customer = request.getParameter("customer");
            String city = request.getParameter("city");
            String region = request.getParameter("region");
            String segment = request.getParameter("segment");
            String projectManager = request.getParameter("projectManager");
            String projectName = request.getParameter("projectName");
            
            // Retrieve the entered project value (assumed to be in INR)
            long projectValue = Long.parseLong(request.getParameter("projectValue"));
            
            // Retrieve the selected currency option (INR, USD, or UKP)
            String currency = request.getParameter("currency");
            
            // Retrieve new fields: Payment Terms and Customer Required Date
            String paymentTerms = request.getParameter("paymentTerms");
            String customerRequiredDateStr = request.getParameter("customerRequiredDate");
            Date customerRequiredDate = null;
            if (customerRequiredDateStr != null && !customerRequiredDateStr.isEmpty()) {
                customerRequiredDate = Date.valueOf(customerRequiredDateStr);
            }
            
            // Create a Project object and set its values.
            Project project = new Project();
            project.setJobNo(jobNo);
            project.setCustomer(customer);
            project.setCity(city);
            project.setRegion(region);
            project.setSegment(segment);
            project.setProjectManager(projectManager);
            project.setProjectName(projectName);
            project.setProjectValue(projectValue); // stored as INR
            project.setCurrency(currency);          // original currency selected
            project.setPaymentTerms(paymentTerms);
            project.setCustomerRequiredDate(customerRequiredDate);
            
            // Insert the project into the database.
            ProjectDAO dao = new ProjectDAO();
            boolean success = dao.addProject(project);
            
            if (success) {
                response.sendRedirect("dashboard");
            } else {
                response.getWriter().println("<h3>Error adding project</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace(response.getWriter());
        }
    }
}
