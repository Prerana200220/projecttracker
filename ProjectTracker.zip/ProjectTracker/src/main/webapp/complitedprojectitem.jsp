<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.example.Item" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ page import="java.text.SimpleDateFormat" %>

<%
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    DecimalFormat df = new DecimalFormat("#,###");
    List<Item> completedItems = (List<Item>) request.getAttribute("completedItems");
    Integer projectId = (Integer) request.getAttribute("projectId");
%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Completed Items for Project ID = <%= projectId %></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-3">
  <h2>Completed Items for Project ID = <%= projectId %></h2>
  <table class="table table-bordered">
    <thead class="table-dark">
      <tr>
        <th>Sr.No.</th>
        <th>ERP No.</th>
        <th>Item Description</th>
        <th>Planned Date</th>
        <th>Completed Date</th>
        <th>Total Value</th>
      </tr>
    </thead>
    <tbody>
    <%
      if (completedItems != null && !completedItems.isEmpty()) {
          int sr = 1;
          for (Item item : completedItems) {
    %>
      <tr>
        <td><%= sr++ %></td>
        <td><%= item.getErpNo() %></td>
        <td><%= item.getItemDescription() %></td>
        <td><%= (item.getPlannedDate() != null) ? sdf.format(item.getPlannedDate()) : "" %></td>
        <td><%= (item.getCompletedDate() != null) ? sdf.format(item.getCompletedDate()) : "" %></td>
        <td class="text-end"><%= df.format(item.getTotalValue()) %></td>
      </tr>
    <%
          }
      } else {
    %>
      <tr>
        <td colspan="6">No completed items found.</td>
      </tr>
    <%
      }
    %>
    </tbody>
  </table>
  <a href="viewItems?projectId=<%= projectId %>" class="btn btn-secondary">Back to Incomplete Items</a>
</div>
</body>
</html>
