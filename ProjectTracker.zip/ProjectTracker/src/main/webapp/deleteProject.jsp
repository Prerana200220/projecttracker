<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.example.Project" %>
<%
    // Retrieve the project object passed by the DeleteProjectServlet.
    Project project = (Project) request.getAttribute("project");
    if (project == null) {
%>
    <h3>Project not found!</h3>
<%
    } else {
%>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Project</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script type="text/javascript">
        // Optional: Confirm deletion using JavaScript.
        function confirmDelete() {
            return confirm("Are you sure you want to delete the project: " + "<%= project.getProjectName() %>" + "?");
        }
    </script>
</head>
  <body>
  <div class="container mt-3">
    <h2>Delete Project</h2>
    <p>Are you sure you want to delete the project: <strong><%= project.getProjectName() %></strong>?</p>
    <form action="deleteProject" method="post" onsubmit="return confirmDelete();">
        <!-- Hidden field to pass the project ID -->
        <input type="hidden" name="projectId" value="<%= project.getId() %>" />
        <button type="submit" class="btn btn-danger">Yes, Delete</button>
        <a href="dashboard" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
<%
    }
%>
