<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List, java.util.Calendar, java.util.Date" %>
<%@ page import="java.text.DecimalFormat, java.text.SimpleDateFormat" %>
<%@ page import="com.example.Project" %>
<%@ page import="com.example.Item" %>
<%@ page import="com.example.ItemDAO" %>  <!-- Make sure this DAO exists -->
<%
    // Check if user is logged in; if not, redirect to login page.
    String role = (String) session.getAttribute("userRole");
    if (role == null) {
        response.sendRedirect("login.jsp?error=Session+expired");
        return;
    }

    // Retrieve last login info from session (assumed to be stored as "yyyy-MM-dd HH:mm:ss")
    String lastLogin = (String) session.getAttribute("lastLogin");
    String formattedLastLogin = "N/A";
    if(lastLogin != null && !lastLogin.trim().isEmpty()){
        try {
            SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date loginDate = originalFormat.parse(lastLogin);
            SimpleDateFormat targetFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            formattedLastLogin = targetFormat.format(loginDate);
        } catch(Exception e) {
            formattedLastLogin = lastLogin; // fallback if parsing fails
        }
    }

    // Retrieve projects from DashboardServlet.
    List<Project> projects = (List<Project>) request.getAttribute("projects");
    if (projects == null) {
        projects = new java.util.ArrayList<>();
    }

    // Format project value with commas.
    DecimalFormat inrFormat = new DecimalFormat("#,###");

    // Date formatter for "Customer Required Date".
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

    // We'll use a Calendar for "today" (year, month, day only).
    Calendar calToday = Calendar.getInstance();
    calToday.setTime(new Date());
%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Project Dashboard - ProjectTracker</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    .container-fluid { padding: 15px; }
    .header-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .header-left {
      display: flex;
      align-items: center;
      gap: 15px;
      flex-wrap: wrap;
    }
    .search-group { display: flex; align-items: center; gap: 5px; }
    .search-group input { height: 34px; font-size: 0.9rem; padding: 4px 8px; }
    .filter-group { display: flex; align-items: center; gap: 5px; }
    .filter-group select, .filter-group input {
      height: 34px; font-size: 0.9rem; padding: 4px 8px; width: 130px;
    }
    .header-right { display: flex; align-items: center; gap: 10px; }
    .header-right a { font-size: 28px; color: #333; text-decoration: none; }
    .header-right a:hover { color: #007bff; }
    .file-upload { display: flex; align-items: center; gap: 5px; }

    .full-screen-table {
      width: 100%;
      margin: 0;
      font-family: Arial, sans-serif;
      font-size: 14px;
    }
    .full-screen-table thead th {
      padding: 8px;
      text-align: center;
      vertical-align: middle;
      background-color: black;
      color: white;
      position: sticky;
      top: 0;
      z-index: 100;
    }
    .full-screen-table tbody td {
      padding: 6px;
      vertical-align: middle;
    }
    .text-right { text-align: right !important; }
    .text-center { text-align: center !important; }
    .text-left { text-align: left !important; }

    .last-login-info {
      position: fixed;
      bottom: 10px;
      right: 10px;
      background: #f9f9f9;
      border: 1px solid #ccc;
      padding: 5px 10px;
      font-size: 0.9rem;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
  </style>
  <script>
    function performSearch() {
      var searchValue = document.getElementById("searchInput").value;
      var filterField = document.getElementById("filterField").value;
      var filterValue = document.getElementById("filterValue").value;
      var url = "dashboard?search=" + encodeURIComponent(searchValue) +
                "&filterField=" + encodeURIComponent(filterField) +
                "&filterValue=" + encodeURIComponent(filterValue);
      window.location.href = url;
    }

    function updateFilterOptions() {
      var filterFieldSelect = document.getElementById("filterField");
      var filterValueSelect = document.getElementById("filterValue");
      var filterField = filterFieldSelect.value;
      filterValueSelect.innerHTML = "";
      var options = [];
      if (filterField === "region") { options = ["North", "East", "West", "South", "Export"]; }
      else if (filterField === "segment") { options = ["Beverage", "Dairy", "Prepared Food", "Equipment"]; }
      else if (filterField === "projectManager") { options = ["Rohit BR", "Nitin Chede", "Jitendra Koli", "Vignesh NPN"]; }
      else if (filterField === "responsibility") { options = ["Unit1", "Unit2", "Bought Out", "Import"]; }
      else {
        filterValueSelect.innerHTML = "<option value=''>--Enter--</option>";
        return;
      }

      var defaultOption = document.createElement("option");
      defaultOption.value = "";
      defaultOption.text = "--Select--";
      filterValueSelect.appendChild(defaultOption);
      for (var i = 0; i < options.length; i++) {
          var opt = document.createElement("option");
          opt.value = options[i];
          opt.text = options[i];
          filterValueSelect.appendChild(opt);
      }
    }
  </script>
</head>
<body>
<div class="container-fluid mt-3">
    <!-- Header with title, search input, filter dropdowns, and Logout -->
    <div class="header-row">
        <div class="header-left">
            <h2><i class="bi bi-list-ul"></i> Project List</h2>
            <div class="search-group">
                <i class="bi bi-search"></i>
                <input type="text" id="searchInput" class="form-control" placeholder="Search...">
                <button class="btn btn-primary" onclick="performSearch()">Search</button>
            </div>
            <div class="filter-group">
                <label for="filterField">Filter By:</label>
                <select id="filterField" class="form-select" onchange="updateFilterOptions()">
                    <option value="region">Region</option>
                    <option value="segment">Segment</option>
                    <option value="projectManager">Project Manager</option>
                    <option value="responsibility">Responsibility</option>
                </select>
                <select id="filterValue" class="form-select"></select>
            </div>
        </div>
        <div class="header-right">
            <a href="addProject.jsp" title="Add New Project"><i class="bi bi-plus-circle"></i></a>
            <a href="weekPlanning?type=weekly" title="Weekly Planning Report"><i class="bi bi-calendar-week"></i></a>
            <a href="weekPlanning?type=projectwise" title="Projectwise Planning Report"><i class="bi bi-calendar-week"></i></a>
            <a href="completedProjects" title="Completed Projects"><i class="bi bi-check-circle-fill"></i></a>
            <a href="logout" title="Logout" class="btn btn-danger btn-sm" style="font-size: 0.8rem;">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>

    <!-- Alert Banner -->
    <div class="alert alert-success text-center">
      <strong><%= role.toUpperCase() %> LOGIN</strong>
    </div>

    <!-- Projects Table -->
    <table class="table table-bordered full-screen-table">
        <thead>
            <tr>
                <th class="text-center">Sr.No.</th>
                <th class="text-center">Job No.</th>
                <th class="text-left">Customer</th>
                <th class="text-center">City</th>
                <th class="text-center">Region</th>
                <th class="text-center">Segment</th>
                <th class="text-center">Project Manager</th>
                <th class="text-left">Project Name</th>
                <th class="text-right">Project Value</th>
                <th class="text-center">Currency</th>
                <th class="text-left">Item Alert</th>
                <th class="text-center">Customer Required Date</th>
                <th class="text-center">Upload File</th>
                <th class="text-center">Actions</th>
            </tr>
        </thead>
        <tbody>
        <%
            int srNo = 1;
            // We'll use a single ItemDAO instance (adjust your package/DAO name if needed)
            ItemDAO itemDao = new ItemDAO();

            for (Project p : projects) {
                // 1) For each project, check if any item is planned for today
                boolean hasItemPlannedToday = false;
                List<Item> projectItems = itemDao.getItemsByProjectId(p.getId());

                for (Item i : projectItems) {
                    if (i.getPlannedDate() != null) {
                        Calendar calItem = Calendar.getInstance();
                        calItem.setTime(i.getPlannedDate());
                        if (calToday.get(Calendar.YEAR) == calItem.get(Calendar.YEAR)
                            && calToday.get(Calendar.DAY_OF_YEAR) == calItem.get(Calendar.DAY_OF_YEAR)) {
                            hasItemPlannedToday = true;
                            break;
                        }
                    }
                }
        %>
            <tr>
                <td class="text-center"><%= srNo++ %></td>
                <td class="text-center"><%= p.getJobNo() %></td>
                <td class="text-left"><%= p.getCustomer() %></td>
                <td class="text-center"><%= p.getCity() %></td>
                <td class="text-center"><%= p.getRegion() %></td>
                <td class="text-center"><%= p.getSegment() %></td>
                <td class="text-center"><%= p.getProjectManager() %></td>
                <td class="text-left"><%= p.getProjectName() %></td>
                <td class="text-right"><%= inrFormat.format(p.getProjectValue()) %></td>
                <td class="text-center"><%= p.getCurrency() %></td>

                <!-- Payment Terms Column -->
                <td class="text-left">
                    <%
                        // 2) If this project has at least one item planned for today, show the red message
                        if (hasItemPlannedToday) {
                    %>
                            <span style="color:red;font-weight:bold;">
                                Some items are planned for today!
                            </span>
                    <%
                        } else {
                            // Otherwise, show normal payment terms
                            out.print((p.getPaymentTerms() != null) ? p.getPaymentTerms() : "");
                        }
                    %>
                </td>

                <td class="text-center">
                    <%= (p.getCustomerRequiredDate() != null) 
                            ? dateFormat.format(p.getCustomerRequiredDate()) 
                            : "" %>
                </td>

                <!-- File Upload + Display -->
                <td class="text-center">
                    <form class="file-upload" action="<%= request.getContextPath() %>/uploadFileServlet" 
                          method="post" enctype="multipart/form-data">
                        <input type="hidden" name="projectId" value="<%= p.getId() %>">
                        <input type="file" name="file" class="form-control form-control-sm" required>
                        <button type="submit" class="btn btn-success btn-sm" title="Upload File">
                          <i class="bi bi-upload"></i>
                        </button>
                    </form>
                    <%
                        if (p.getFileName() != null && !p.getFileName().isEmpty()) {
                    %>
                        <div class="mt-1">
                            <i class="bi bi-file-earmark"></i>
                            <a href="<%= request.getContextPath() %>/uploads/<%= p.getFileName() %>" 
                               target="_blank">
                                <%= p.getFileName() %>
                            </a>
                            <!-- Delete File Link -->
                            <a href="<%= request.getContextPath() %>/deleteFile?projectId=<%= p.getId() %>&fileName=<%= p.getFileName() %>" 
                               title="Delete File"
                               onclick="return confirm('Are you sure you want to delete project: <%= p.getProjectName() %>?');">
                               <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    <%
                        }
                    %>
                </td>

                <td class="text-center">
                    <% if (role.equalsIgnoreCase("admin")) { %>
                        <a class="btn btn-warning btn-sm" 
                           href="editProject?projectId=<%= p.getId() %>" 
                           title="Update">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <a class="btn btn-danger btn-sm" 
                           href="deleteProject?projectId=<%= p.getId() %>" 
                           title="Delete"
                           onclick="return confirm('Are you sure you want to delete project: <%= p.getProjectName() %>?');">
                            <i class="bi bi-trash"></i>
                        </a>
                    <a class="btn btn-success btn-sm" 
                       href="paymentphase.jsp?projectId=<%= p.getId() %>&projectName=<%= java.net.URLEncoder.encode(p.getProjectName(), "UTF-8") %>" 
                       title="View Payment Phase">
                        <i class="bi bi-cash"></i>
                    </a>
                    <% } %>
                    <a class="btn btn-info btn-sm" 
                       href="viewItems?projectId=<%= p.getId() %>" 
                       title="View">
                        <i class="bi bi-eye"></i>
                    </a>
                   
                </td>
            </tr>
        <%
            }
        %>
        </tbody>
    </table>

    <!-- Pagination (Placeholder) -->
    <div class="d-flex justify-content-end">
        <span class="me-2">Page 1 of n</span>
        <button class="btn btn-sm btn-outline-primary me-2">Next</button>
        <input type="text" class="form-control-sm me-2" placeholder="Jump to page">
        <button class="btn btn-sm btn-primary">Go</button>
    </div>
</div>

<!-- Fixed Footer for Last Login Info -->
<div class="last-login-info">
    Last Login: <%= formattedLastLogin %>
</div>
</body>
</html>
