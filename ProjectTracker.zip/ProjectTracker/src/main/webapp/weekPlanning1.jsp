<%@ page contentType="text/html;charset=UTF-8" language="java" %> 
<%@ page import="java.util.*, java.text.*, com.example.Project, com.example.Item, java.util.Calendar" %>
<%!
    // --- 1. Define static base dates for week calculations ---
    private static final Calendar base2025;
    private static final Calendar base2026;
    static {
        base2025 = Calendar.getInstance();
        base2026 = Calendar.getInstance();
        // Base for 2025: April 1, 2025
        base2025.set(2025, Calendar.APRIL, 1, 0, 0, 0);
        base2025.set(Calendar.MILLISECOND, 0);
        // Base for 2026: January 8, 2026
        base2026.set(2026, Calendar.JANUARY, 8, 0, 0, 0);
        base2026.set(Calendar.MILLISECOND, 0);
    }
    
    // --- 2. Helper method to compute a week key from a planned date ---
    public String getWeekKey(Date plannedDate) {
        if (plannedDate == null) return null;
        Calendar cal = Calendar.getInstance();
        cal.setTime(plannedDate);
        int year = cal.get(Calendar.YEAR);
        if (year == 2025) {
            long diffMillis = plannedDate.getTime() - base2025.getTimeInMillis();
            long diffDays = diffMillis / (24L * 60L * 60L * 1000L);
            int week = 14 + (int)(diffDays / 7);
            if (week < 14 || week > 52) return null;
            return "W-" + week + "(25)";
        } else if (year == 2026) {
            long diffMillis = plannedDate.getTime() - base2026.getTimeInMillis();
            long diffDays = diffMillis / (24L * 60L * 60L * 1000L);
            int week = 1 + (int)(diffDays / 7);
            if (week < 1 || week > 14) return null;
            return "W-" + week + "(26)";
        } else {
            return null;
        }
    }
    
    // --- 3. Helper method to convert a List of Map (with keys date and value) to JSON ---
    public String listMapToJson(List<Map<String, Object>> list) {
        if (list == null || list.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        boolean first = true;
        for (Map<String, Object> map : list) {
            if (!first) sb.append(",");
            sb.append("{");
            boolean innerFirst = true;
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (!innerFirst) sb.append(",");
                sb.append("\"").append(entry.getKey()).append("\":");
                Object value = entry.getValue();
                if (value instanceof Number) {
                    sb.append(value);
                } else {
                    sb.append("\"").append(value).append("\"");
                }
                innerFirst = false;
            }
            sb.append("}");
            first = false;
        }
        sb.append("]");
        return sb.toString();
    }
%>

<%
    // --- 4. Retrieve projects from request scope ---
    List<Project> projects = (List<Project>) request.getAttribute("projects");
    if (projects == null) {
        projects = new ArrayList<Project>();
    }
    
    // --- 5. Build the list of week columns ---
    List<String> weekColumns = new ArrayList<String>();
    for (int w = 14; w <= 52; w++) {
        weekColumns.add("W-" + w + "(25)");
    }
    for (int w = 1; w <= 14; w++) {
        weekColumns.add("W-" + w + "(26)");
    }
    
    // --- 6. Compute per-project week sums (mapping: week key -> sum) ---
    // Only include items that have a planning date and NO completion date.
    Map<Integer, Map<String, Double>> projectWeekSums = new HashMap<Integer, Map<String, Double>>();
    for (Project p : projects) {
        Map<String, Double> sums = new HashMap<String, Double>();
        if (p.getItems() != null) {
            for (Item it : p.getItems()) {
                if (it.getPlannedDate() != null && it.getCompletedDate() == null) {
                    String weekKey = getWeekKey(it.getPlannedDate());
                    if (weekKey != null) {
                        double oldVal = sums.getOrDefault(weekKey, 0.0);
                        sums.put(weekKey, oldVal + it.getTotalValue());
                    }
                }
            }
        }
        projectWeekSums.put(p.getId(), sums);
    }
    
    // --- 7. Compute per-project week breakdowns (for modal – not used now) ---
    Map<Integer, Map<String, List<Map<String, Object>>>> projectWeekBreakdowns = new HashMap<>();
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    for (Project p : projects) {
        Map<String, List<Map<String, Object>>> breakdownForProject = new HashMap<>();
        if (p.getItems() != null) {
            for (Item it : p.getItems()) {
                if (it.getPlannedDate() != null && it.getCompletedDate() == null) {
                    String weekKey = getWeekKey(it.getPlannedDate());
                    if (weekKey != null) {
                        String dateStr = sdf.format(it.getPlannedDate());
                        Map<String, Object> entry = new HashMap<>();
                        entry.put("date", dateStr);
                        entry.put("value", it.getTotalValue());
                        entry.put("Sr.No", it.getSrNo());
                        List<Map<String, Object>> list = breakdownForProject.getOrDefault(weekKey, new ArrayList<>());
                        list.add(entry);
                        breakdownForProject.put(weekKey, list);
                    }
                }
            }
        }
        projectWeekBreakdowns.put(p.getId(), breakdownForProject);
    }
    
    // --- 8. Compute aggregated totals per week ---
    Map<String, Double> aggWeekTotals = new HashMap<>();
    for (String wk : weekColumns) {
        aggWeekTotals.put(wk, 0.0);
    }
    for (Project p : projects) {
        Map<String, Double> sums = projectWeekSums.getOrDefault(p.getId(), new HashMap<>());
        for (Map.Entry<String, Double> entry : sums.entrySet()) {
            String wk = entry.getKey();
            double current = aggWeekTotals.getOrDefault(wk, 0.0);
            aggWeekTotals.put(wk, current + entry.getValue());
        }
    }
    
    // --- 9. Compute overall aggregated total ---
    double overallAggTotal = 0.0;
    for (String wk : aggWeekTotals.keySet()) {
        overallAggTotal += aggWeekTotals.get(wk);
    }
    
    // --- 10. DecimalFormat for numeric values ---
    DecimalFormat df = new DecimalFormat("#,###");
%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Report: Project Wise Planning</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Include Bootstrap Bundle (with Popper) for modal support if needed -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <!-- Include html2canvas and jsPDF for PDF download -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
      white-space: nowrap;
      margin: 0;
      font-size: 13px;
    }
    th, td {
      border: 2px solid #333;  /* Thicker borders */
      padding: 4px;
      vertical-align: middle;
    }
    th.project-heading {
      background-color: #444;
      color: #f8f9fa;
      text-align: left;
    }
    th.week-heading-even {
      background-color: #fff4f2;
      color: #000;
      text-align: center;
      width: 80px;
    }
    th.week-heading-odd {
      background-color: #d5ffff;
      color: #000;
      text-align: center;
      width: 80px;
    }
    th.total-row {
      background-color: #444;
      color: #f8f9fa;
      font-weight: bold;
      text-align: right;
      font-size: 15px;
    }
    th.total-planned, td.total-planned {
      font-size: 15px;
      font-weight: bold;
    }
    .text-end {
      text-align: right;
    }
    .container-fluid {
      margin-left: 0;
      padding-left: 0;
    }
    @media print {
      .no-print { display: none; }
    }
  </style>
</head>
<body>
<!-- Wrap everything in an element with id="pdfContent" -->
<div id="pdfContent">
  <div class="container-fluid mt-3">
    <h2>Report: Project Wise Planning</h2>
    <div class="mb-3 no-print">
      <button type="button" class="btn btn-primary" onclick="window.print()">Print</button>
      <button type="button" class="btn btn-success" onclick="downloadPDF()">Download PDF</button>
      <a href="dashboard" class="btn btn-secondary no-print">Back to Dashboard</a>
    </div>
    
    <table class="table table-bordered">
      <thead>
        <tr>
          <th class="project-heading">Job No.</th>
          <th class="project-heading">Customer</th>
          <th class="project-heading">City</th>
          <th class="project-heading">Region</th>
          <th class="project-heading">Segment</th>
          <th class="project-heading">Project Manager</th>
          <th class="project-heading text-end">Project Value</th>
          <th class="project-heading">Project Name</th>
          <th class="project-heading text-end total-planned">Totals</th>
          <% for (int i = 0; i < weekColumns.size(); i++) {
               String col = weekColumns.get(i);
               String cssClass = (i % 2 == 0) ? "week-heading-even" : "week-heading-odd";
          %>
            <th class="<%= cssClass %>"><%= col %></th>
          <% } %>
        </tr>
        
        <tr>
          <th colspan="8" class="total-row">Totals</th>
          <th class="total-row total-planned"><%= overallAggTotal != 0.0 ? df.format(overallAggTotal) : "" %></th>
          <% for (String wc : weekColumns) {
               double aggVal = aggWeekTotals.getOrDefault(wc, 0.0);
          %>
            <th class="total-row"><%= aggVal != 0.0 ? df.format(aggVal) : "" %></th>
          <% } %>
        </tr>
      </thead>
      <tbody>
        <% for (Project p : projects) {
               Map<String, Double> sums = projectWeekSums.getOrDefault(p.getId(), new HashMap<String, Double>());
               double totalPlanned = 0.0;
               for (String wc : weekColumns) {
                   totalPlanned += sums.getOrDefault(wc, 0.0);
               }
        %>
        <tr>
          <td><%= p.getJobNo() %></td>
          <td><%= p.getCustomer() %></td>
          <td><%= p.getCity() %></td>
          <td><%= p.getRegion() %></td>
          <td><%= p.getSegment() %></td>
          <td><%= p.getProjectManager() %></td>
          <td class="text-end"><%= df.format(p.getProjectValue()) %></td>
          <td><%= p.getProjectName() %></td>
          <td class="text-end total-planned">
            <% if(totalPlanned != 0.0) { %>
              <a href="viewItems?projectId=<%= p.getId() %>"><%= df.format(totalPlanned) %></a>
            <% } %>
          </td>
          <% for (String wc : weekColumns) {
               double val = sums.getOrDefault(wc, 0.0);
          %>
            <td class="text-end">
              <% if(val != 0.0) { %>
                <a href="viewitems1.jsp?projectId=<%= p.getId() %>&weekKey=<%= wc %>" class="btn btn-link">
                  <%= df.format(val) %>
                </a>
              <% } else { %>
                <%= "" %>
              <% } %>
            </td>
          <% } %>
        </tr>
        <% } %>
      </tbody>
    </table>
    <br>
  </div>
</div>

<!-- Modal code remains here in case you need it elsewhere -->
<div class="modal fade" id="breakdownModal" tabindex="-1" aria-labelledby="breakdownModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="breakdownModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="breakdownModalBody"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
  // PDF download function remains unchanged
  function downloadPDF() {
    const pdfContent = document.getElementById("pdfContent");
    if (!pdfContent) return;
    html2canvas(pdfContent, {
      scrollX: 0,
      scrollY: 0,
      windowWidth: pdfContent.scrollWidth,
      windowHeight: pdfContent.scrollHeight
    }).then(function(canvas) {
      const { jsPDF } = window.jspdf;
      const imgData = canvas.toDataURL("image/png");
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      const pxPerPt = 96 / 72;
      const pdfWidth = canvasWidth / pxPerPt;
      const pdfHeight = canvasHeight / pxPerPt;
      const pdf = new jsPDF("l", "pt", [pdfWidth, pdfHeight]);
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save("report.pdf");
    });
  }
</script>
</body>
</html>
