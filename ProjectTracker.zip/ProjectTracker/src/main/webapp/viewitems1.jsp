<%@ page contentType="text/html;charset=UTF-8" language="java" %>   
<%@ page import="java.util.*, java.text.*, com.example.Item, com.example.ItemDAO, com.example.Project, com.example.ProjectDAO" %>
<%!
    private static final Calendar base2025;
    private static final Calendar base2026;
    static {
        base2025 = Calendar.getInstance();
        base2026 = Calendar.getInstance();
        base2025.set(2025, Calendar.APRIL, 1, 0, 0, 0);
        base2025.set(Calendar.MILLISECOND, 0);
        base2026.set(2026, Calendar.JANUARY, 8, 0, 0, 0);
        base2026.set(Calendar.MILLISECOND, 0);
    }
    // Returns a "W-xx(25/26)" or null if out of range
    public String getWeekKey(Date plannedDate) {
        if (plannedDate == null) return null;
        Calendar cal = Calendar.getInstance();
        cal.setTime(plannedDate);
        int year = cal.get(Calendar.YEAR);
        if (year == 2025) {
            long diffMillis = plannedDate.getTime() - base2025.getTimeInMillis();
            long diffDays = diffMillis / (24L * 60L * 60L * 1000L);
            int week = 14 + (int)(diffDays / 7);
            if (week < 14 || week > 52) return null;
            return "W-" + week + "(25)";
        } else if (year == 2026) {
            long diffMillis = plannedDate.getTime() - base2026.getTimeInMillis();
            long diffDays = diffMillis / (24L * 60L * 60L * 1000L);
            int week = 1 + (int)(diffDays / 7);
            if (week < 1 || week > 14) return null;
            return "W-" + week + "(26)";
        } else {
            return null;
        }
    }
%>
<%
    String weekKeyParam = request.getParameter("weekKey");
    String projectIdParam = request.getParameter("projectId");
    int projectId = 0;
    if (projectIdParam != null) {
        projectId = Integer.parseInt(projectIdParam);
    }

    // Load the project
    ProjectDAO projectDao = new ProjectDAO();
    Project project = projectDao.getProjectById(projectId);

    // Load items
    ItemDAO itemDao = new ItemDAO();
    List<Item> allItems = itemDao.getItemsByProjectId(projectId);
    if (allItems == null) {
        allItems = new ArrayList<Item>();
    }

    // Filter by week key
    List<Item> filteredItems = new ArrayList<>();
    double totalValueSum = 0;
    if (weekKeyParam != null) {
        for (Item item : allItems) {
            if (item.getPlannedDate() != null) {
                String wk = getWeekKey(item.getPlannedDate());
                if (wk != null && wk.equals(weekKeyParam)) {
                    filteredItems.add(item);
                    totalValueSum += item.getTotalValue();
                }
            }
        }
    }

    // Formatters
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    DecimalFormat df = new DecimalFormat("#,###.##");

    // "Today" for highlighting
    Calendar calToday = Calendar.getInstance();
    calToday.setTime(new Date());
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Items for Week <%= weekKeyParam %></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <link rel="icon" href="<%= request.getContextPath() %>/assets/images/Logo.png" type="image/png">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #333;
            padding: 8px;
            vertical-align: middle;
        }
        .table thead th {
            background-color: black !important;
            color: white !important;
        }
        .sr-no       { width: 50px; text-align: left; }
        .erp-no      { width: 120px; text-align: left; }
        .item-desc   { width: 400px; text-align: left; }
        .capacity    { width: 100px; text-align: left; }
        .qty         { width: 80px; text-align: left; }
        .unit-value  { width: 120px; text-align: left; }
        .total-value { width: 120px; text-align: right; font-weight: bold; }
        .responsibility { width: 150px; text-align: left; }
        .planned-date   { width: 150px; text-align: left; }
        .completed-date { width: 150px; text-align: left; }
        .delay-reason   { width: 150px; text-align: left; }
        .total-sum {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #d9534f;
        }
        .btn-group { margin-bottom: 15px; }
    </style>
    <script>
        function printPage() {
            window.print();
        }
        function downloadPDF() {
            var pdfContent = document.getElementById("pdfContent");
            if (!pdfContent) return;
            html2canvas(pdfContent, {
                scrollX: 0,
                scrollY: 0,
                windowWidth: pdfContent.scrollWidth,
                windowHeight: pdfContent.scrollHeight
            }).then(function(canvas) {
                const { jsPDF } = window.jspdf;
                const imgData = canvas.toDataURL("image/png");
                const canvasWidth = canvas.width;
                const canvasHeight = canvas.height;
                const pxPerPt = 96 / 72;
                const pdfWidth = canvasWidth / pxPerPt;
                const pdfHeight = canvasHeight / pxPerPt;
                const pdf = new jsPDF("l", "pt", [pdfWidth, pdfHeight]);
                pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
                pdf.save("Items_for_Week_<%= weekKeyParam %>.pdf");
            });
        }
    </script>
</head>
<body>
    <div class="container mt-4" id="pdfContent">
        <h2>
          Items for Project: 
          <span style="color: blue;">
            <%= (project != null) ? project.getProjectName() : "Unknown Project" %>
          </span>
          for Week <span style="color: green;"><%= weekKeyParam %></span>
        </h2>
        
        <div class="total-sum">Total Value: ₹<%= df.format(totalValueSum) %></div>
        
        <div class="mb-3 no-print">
            <button type="button" class="btn btn-primary" onclick="printPage()">Print</button>
            <!-- <button type="button" class="btn btn-success" onclick="downloadPDF()">Download PDF</button> -->
            <a href="weekPlanning?type=projectwise" class="btn btn-secondary no-print">Back to weekPlanning</a>
        </div>
        
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="sr-no">Sr.No</th>
                    <th class="erp-no">ERP No</th>
                    <th class="item-desc">Item Description</th>
                    <th class="capacity">Capacity</th>
                    <th class="qty">Qty</th>
                    <th class="unit-value">Unit Value</th>
                    <th class="total-value">Total Value</th>
                    <th class="responsibility">Responsibility</th>
                    <th class="planned-date">Planned Date</th>
                    <th class="completed-date">Completed Date</th>
                    <th class="delay-reason">Reason for Delay</th>
                </tr>
            </thead>
            <tbody>
                <% if (filteredItems.isEmpty()) { %>
                    <tr><td colspan="11">No items found for this week.</td></tr>
                <% } else {
                       int counter = 1;
                       // Create a Calendar for the item to compare with "today"
                       for (Item item : filteredItems) {
                           boolean highlight = false;
                           if (item.getPlannedDate() != null) {
                               Calendar calItem = Calendar.getInstance();
                               calItem.setTime(item.getPlannedDate());
                               if (calToday.get(Calendar.YEAR) == calItem.get(Calendar.YEAR)
                                   && calToday.get(Calendar.DAY_OF_YEAR) == calItem.get(Calendar.DAY_OF_YEAR)) {
                                   highlight = true;
                               }
                           }

                           // We'll store the inline style if highlight = true
                           String highlightStyle = highlight ? "color:red !important; font-weight:bold !important;" : "";
                %>
                    <tr>
                        <!-- For each cell, apply the highlightStyle inline so nothing overrides it -->
                        <td class="sr-no" style="<%= highlightStyle %>"><%= counter++ %></td>
                        <td class="erp-no" style="<%= highlightStyle %>"><%= item.getErpNo() %></td>
                        <td class="item-desc" style="<%= highlightStyle %>"><%= item.getItemDescription() %></td>
                        <td class="capacity" style="<%= highlightStyle %>"><%= item.getCapacity() %></td>
                        <td class="qty" style="<%= highlightStyle %>"><%= item.getQty() %></td>
                        <td class="unit-value" style="<%= highlightStyle %>"><%= df.format(item.getUnitValue()) %></td>
                        <td class="total-value" style="<%= highlightStyle %>"><%= df.format(item.getTotalValue()) %></td>
                        <td class="responsibility" style="<%= highlightStyle %>"><%= item.getResponsibility() %></td>
                        <td class="planned-date" style="<%= highlightStyle %>">
                            <%= sdf.format(item.getPlannedDate()) %>
                        </td>
                        <td class="completed-date" style="<%= highlightStyle %>">
                            <%= (item.getCompletedDate() != null) ? sdf.format(item.getCompletedDate()) : "" %>
                        </td>
                        <td class="delay-reason" style="<%= highlightStyle %>">
                            <%= (item.getDelayReason() != null && !item.getDelayReason().trim().isEmpty())
                                 ? item.getDelayReason() : "-" %>
                        </td>
                    </tr>
                <%   }
                   }
                %>
            </tbody>
        </table>
    </div>
</body>
</html>
