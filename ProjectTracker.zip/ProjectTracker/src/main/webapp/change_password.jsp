<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="jakarta.servlet.http.HttpSession" %>
<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Change Password</h2>
        
        <%
            // Retrieve session data
            HttpSession userSession = request.getSession();
            String username = (String) userSession.getAttribute("username");
            String email = (String) userSession.getAttribute("email");
            String error = (String) request.getAttribute("error");
            String message = (String) request.getAttribute("message");

            if (error != null) {
        %>
            <div class="alert alert-danger"><%= error %></div>
        <% } %>
        <% if (message != null) { %>
            <div class="alert alert-success"><%= message %></div>
        <% } %>

        <form action="ChangePassword" method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" name="username" class="form-control" value="<%= (username != null) ? username : "" %>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="text" name="email" class="form-control" value="<%= (email != null) ? email : "" %>" disabled>
            </div>
            <div class="mb-3">
                <label for="currentPassword" class="form-label">Current Password:</label>
                <input type="password" name="currentPassword" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="newPassword" class="form-label">New Password:</label>
                <input type="password" name="newPassword" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="confirmPassword" class="form-label">Confirm New Password:</label>
                <input type="password" name="confirmPassword" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
    </div>
</body>
</html>
