<%@ page contentType="text/html;charset=UTF-8" language="java" %> 
<%@ page import="com.example.Item" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    // Retrieve the item and project ID from request attributes.
    Item item = (Item) request.getAttribute("item");
    int projectId = (Integer) request.getAttribute("projectId");
    
    // Retrieve user role from session.
    String userRole = (String) session.getAttribute("userRole");
    boolean isSecondAdmin = "secondAdmin".equals(userRole);
    
    // Formatter for HTML input (ISO format required by input type="date")
    SimpleDateFormat htmlSdf = new SimpleDateFormat("yyyy-MM-dd");
    // Formatter for display purposes (dd-MM-yyyy)
    SimpleDateFormat displaySdf = new SimpleDateFormat("dd-MM-yyyy");
    DecimalFormat numberFormat = new DecimalFormat("#,###");
    
    if (item == null) {
%>
    <h3>Item not found!</h3>
<%
    } else {
%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Item - <%= item.getItemDescription() %></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    input[type="text"] { text-align: left; }
  </style>
  <script>
    function removeCommasBeforeSubmit() {
      var unitValueField = document.getElementById("unitValue");
      if (unitValueField) {
        unitValueField.value = unitValueField.value.replace(/,/g, '');
      }
      return true;
    }
    
    function checkDelay() {
      var plannedDate = document.getElementsByName("plannedDate")[0].value;
      var delayReasonDiv = document.getElementById("delayReasonDiv");
      var delayReasonInput = document.getElementById("delayReason");
      if (plannedDate !== "") {
          delayReasonDiv.style.display = "block";
          delayReasonInput.required = true;
      } else {
          delayReasonDiv.style.display = "none";
          delayReasonInput.required = false;
      }
    }
  </script>
</head>
<body>
<div class="container mt-3">
  <h2>Edit Item</h2>
  
  <!-- Main Update Form -->
  <form action="editItem" method="post" onsubmit="return removeCommasBeforeSubmit();">
    <input type="hidden" name="itemId" value="<%= item.getId() %>">
    <input type="hidden" name="projectId" value="<%= projectId %>">
    <!-- Hidden field to preserve Planned Date -->
    <input type="hidden" name="plannedDate" value="<%= (item.getPlannedDate() != null) ? htmlSdf.format(item.getPlannedDate()) : "" %>">
    
    <!-- SR No. -->
    <div class="mb-3">
      <label>SR No.</label>
      <input type="text" name="srNo" class="form-control" value="<%= item.getSrNo() != null ? item.getSrNo() : "" %>" required <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- ERP No. -->
    <div class="mb-3">
      <label>ERP No.</label>
      <input type="text" name="erpNo" class="form-control" value="<%= item.getErpNo() %>" required <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- Item Description -->
    <div class="mb-3">
      <label>Item Description</label>
      <textarea name="itemDescription" class="form-control" rows="4" required <%= isSecondAdmin ? "readonly" : "" %>><%= item.getItemDescription() %></textarea>
    </div>
    
    <!-- Capacity -->
    <div class="mb-3">
      <label>Capacity</label>
      <input type="text" name="capacity" class="form-control" value="<%= item.getCapacity() %>" <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- Quantity -->
    <div class="mb-3">
      <label>Quantity</label>
      <input type="number" name="qty" class="form-control" value="<%= item.getQty() %>" required <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- Unit Value -->
    <div class="mb-3">
      <label>Unit Value</label>
      <input type="text" id="unitValue" name="unitValue" class="form-control" value="<%= numberFormat.format(item.getUnitValue()) %>" required <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- Responsibility -->
    <div class="mb-3">
      <label>Responsibility</label>
      <% if(isSecondAdmin){ %>
        <input type="text" name="responsibility" class="form-control" 
          value="<%= item.getResponsibility() != null && !item.getResponsibility().trim().isEmpty() ? item.getResponsibility() : "-" %>" readonly>
        <input type="hidden" name="responsibility" 
          value="<%= item.getResponsibility() != null && !item.getResponsibility().trim().isEmpty() ? item.getResponsibility() : "-" %>">
      <% } else { %>
        <select name="responsibility" class="form-control" required>
          <option value="-" <%= (item.getResponsibility() == null || item.getResponsibility().trim().isEmpty()) ? "selected" : "" %>>-</option>
          <option value="Unit1" <%= "Unit1".equals(item.getResponsibility()) ? "selected" : "" %>>Unit1</option>
          <option value="Unit2" <%= "Unit2".equals(item.getResponsibility()) ? "selected" : "" %>>Unit2</option>
          <option value="Bought Out" <%= "Bought Out".equals(item.getResponsibility()) ? "selected" : "" %>>Bought Out</option>
          <option value="Import" <%= "Import".equals(item.getResponsibility()) ? "selected" : "" %>>Import</option>
        </select>
      <% } %>
    </div>
    
    <!-- Display Planned Date (read-only using display format dd-MM-yyyy) -->
    <div class="mb-3">
      <label>Planned Date</label>
      <input type="text" class="form-control" value="<%= (item.getPlannedDate() != null) ? displaySdf.format(item.getPlannedDate()) : "Not set" %>" readonly>
    </div>
    
    <!-- Completed Date -->
    <div class="mb-3">
      <label>Completed Date</label>
      <input type="date" name="completedDate" class="form-control" 
             value="<%= (item.getCompletedDate() != null) ? htmlSdf.format(item.getCompletedDate()) : "" %>" <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- Status -->
    <div class="mb-3">
      <label>Status</label>
      <input type="text" name="status" class="form-control" 
             value="<%= (item.getStatus() != null) ? item.getStatus() : "" %>" <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <!-- Ready By -->
    <div class="mb-3">
      <label>Ready By</label>
      <input type="date" name="ready_by" class="form-control" 
             value="<%= (item.getReadyBy() != null) ? htmlSdf.format(item.getReadyBy()) : "" %>" <%= isSecondAdmin ? "readonly" : "" %>>
    </div>
    
    <button type="submit" class="btn btn-primary">Update Item</button>
    <a href="viewItems?projectId=<%= projectId %>" class="btn btn-secondary">Cancel</a>
  </form>
  
  <hr>
  
  <!-- New Form to Update Planned Date & Notify MD -->
  <h4>Update Planned Date & Notify MD</h4>
  <form action="updatePlannedDate" method="post">
    <input type="hidden" name="itemId" value="<%= item.getId() %>">
    <input type="hidden" name="projectId" value="<%= projectId %>">
    <p>Current Planned Date: <%= (item.getPlannedDate() != null) ? displaySdf.format(item.getPlannedDate()) : "Not set" %></p>
    <div class="mb-3">
      <label>New Planned Date</label>
      <input type="date" name="newPlannedDate" class="form-control" required>
    </div>
    <!-- Reason for Delay -->
    <div class="mb-3">
      <label>Reason for Delay</label>
      <input type="text" name="newDelayReason" class="form-control" placeholder="Enter reason for delay" required>
    </div>
    <button type="submit" class="btn btn-warning">Update Planned Date & Send Email</button>
  </form>
</div>
</body>
</html>
<% } %>
