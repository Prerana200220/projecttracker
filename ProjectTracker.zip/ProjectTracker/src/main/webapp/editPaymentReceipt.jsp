<%@ page import="java.util.*, java.text.SimpleDateFormat, com.example.PaymentReceipt, com.example.PaymentReceiptDAO" %> 
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Retrieve required parameters from the URL
    String receiptIdParam = request.getParameter("receiptId");
    String projectIdParam = request.getParameter("projectId");
    String projectName = request.getParameter("projectName");
    
    if(receiptIdParam == null || receiptIdParam.trim().isEmpty() ||
       projectIdParam == null || projectIdParam.trim().isEmpty() ||
       projectName == null || projectName.trim().isEmpty()){
%>
    <div class="alert alert-danger">Missing parameters. Please ensure receiptId, projectId, and projectName are provided.</div>
<%
        return;
    }
    
    int receiptId = Integer.parseInt(receiptIdParam);
    int projectId = Integer.parseInt(projectIdParam);
    
    // Get the PaymentReceipt from the database
    PaymentReceiptDAO dao = new PaymentReceiptDAO();
    PaymentReceipt receipt = dao.getPaymentReceiptById(receiptId);
    if(receipt == null){
%>
    <div class="alert alert-danger">Payment receipt not found.</div>
<%
        return;
    }
    
    // Optionally, format the date if needed (assumes stored format is "yyyy-MM-dd")
    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
    String formattedDate = receipt.getPaymentDate();
    if(formattedDate != null && !formattedDate.trim().isEmpty()){
        try{
            Date dateObj = inputFormat.parse(formattedDate);
            formattedDate = outputFormat.format(dateObj);
        } catch(Exception e){
            // Fallback to original value if parsing fails
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Payment Receipt for <%= projectName %> (Receipt ID: <%= receiptId %>)</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Include Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
      body {
          font-family: Arial, sans-serif;
          font-size: 14px;
          background-color: #ffffff;
      }
  </style>
</head>
<body>
<div class="container mt-4">
  <h4>Edit Payment Receipt for <%= projectName %> (Receipt ID: <%= receiptId %>)</h4>
  <form action="UpdatePaymentReceiptServlet" method="post">
    <!-- Hidden fields to pass necessary IDs and project name -->
    <input type="hidden" name="receiptId" value="<%= receiptId %>">
    <input type="hidden" name="projectId" value="<%= projectId %>">
    <input type="hidden" name="projectName" value="<%= projectName %>">
    
    <div class="mb-3">
      <label for="paymentPhase" class="form-label">Payment Phase:</label>
      <select name="paymentPhase" class="form-select" required>
         <option value="">--Select Phase--</option>
         <option value="Advance" <%= "Advance".equals(receipt.getPaymentPhase()) ? "selected" : "" %>>Advance</option>
         <option value="Mid-stage" <%= "Mid-stage".equals(receipt.getPaymentPhase()) ? "selected" : "" %>>Mid-stage</option>
         <option value="Before Despatch" <%= "Before Despatch".equals(receipt.getPaymentPhase()) ? "selected" : "" %>>Before Despatch</option>
         <option value="After Commissioning" <%= "After Commissioning".equals(receipt.getPaymentPhase()) ? "selected" : "" %>>After Commissioning</option>
      </select>
    </div>
    
    <div class="mb-3">
      <label for="amount" class="form-label">Amount:</label>
      <input type="number" step="0.01" name="amount" class="form-control" value="<%= receipt.getAmount() %>" required>
    </div>
    
    <div class="mb-3">
      <label for="mode" class="form-label">Currency / Mode:</label>
      <select name="mode" class="form-select" required>
         <option value="">--Select--</option>
         <option value="₹" <%= "₹".equals(receipt.getMode()) ? "selected" : "" %>>₹</option>
         <option value="$" <%= "$".equals(receipt.getMode()) ? "selected" : "" %>>$</option>
         <option value="£" <%= "£".equals(receipt.getMode()) ? "selected" : "" %>>£</option>
         <option value="€" <%= "€".equals(receipt.getMode()) ? "selected" : "" %>>€</option>
      </select>
    </div>
    
    <div class="mb-3">
      <label for="paymentDate" class="form-label">Payment Date:</label>
      <input type="date" name="paymentDate" class="form-control" value="<%= receipt.getPaymentDate() %>" required>
    </div>
    
    <div class="mb-3">
      <label for="remarks" class="form-label">Remarks / Payment Terms:</label>
      <textarea name="remarks" class="form-control" maxlength="20000"><%= receipt.getRemarks() %></textarea>
    </div>
    
    <button type="submit" class="btn btn-success">Update Payment Receipt</button>
    <a href="paymentphase.jsp?projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>" class="btn btn-secondary">
      <i class="bi bi-arrow-left-circle"></i> Cancel
    </a>
  </form>
</div>
</body>
</html>
