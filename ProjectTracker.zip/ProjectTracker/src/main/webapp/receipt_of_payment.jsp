<%@ page import="java.util.*, java.text.SimpleDateFormat, java.text.DecimalFormat, com.example.PaymentReceipt, com.example.PaymentReceiptDAO" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Retrieve projectId and projectName from request parameters
    String projParam = request.getParameter("projectId");
    String projectName = request.getParameter("projectName");

    // Ensure both parameters are provided
    if (projParam == null || projParam.trim().isEmpty() ||
        projectName == null || projectName.trim().isEmpty()) {
%>
    <div class="alert alert-danger">
        Project ID or Project Name not provided.
    </div>
<%
        return;
    }
    
    int projectId = Integer.parseInt(projParam);
    String message = request.getParameter("message");
    
    // Fetch payments for this project
    PaymentReceiptDAO dao = new PaymentReceiptDAO();
    List<PaymentReceipt> payments = dao.getPaymentsByProject(projectId);
    
    // DecimalFormat for amount (e.g., 300,000.00)
    DecimalFormat amountFormat = new DecimalFormat("#,###.##");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receipt of Payment for <%= projectName %> (Project ID: <%= projectId %>)</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Include Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            font-family: Arial, sans-serif;  /* uniform font */
            font-size: 14px;                 /* uniform font size */
            background-color: #ffffff;       /* white background */
        }
        /* Header buttons container aligned at top-right */
        .header-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-bottom: 20px;
        }
        /* Custom style for the Back to Payment Phase button */
        .recipt-show-bull {
            background-color: #ffc107;
            color: #000;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <!-- Header Buttons: All buttons on the top-right -->
    <div class="header-buttons">
        <!-- Add Receipt Button -->
        <a href="receipt_of_payment.jsp?projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>" 
           class="btn btn-primary btn-sm" title="Add Payment Receipt">
           <i class="bi bi-plus-circle"></i> Add Receipt
        </a>
        <!-- Back to Payment Phase Button (with custom class) -->
        <a href="paymentphase.jsp?projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>" 
           class="btn btn-info btn-sm recipt-show-bull" title="Back to Payment Phase">
           <i class="bi bi-arrow-left-circle"></i> Back to Payment Phase
        </a>
        <!-- Dashboard Button -->
        <a href="dashboard?projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>" 
           class="btn btn-secondary btn-sm" title="Dashboard">
           <i class="bi bi-house"></i> Dashboard
        </a>
    </div>
    
    <!-- Smaller Heading: Display project name -->
    <h5>Add Receipt of Payment : <%= projectName %></h5>
    
    <% if(message != null) { %>
        <div class="alert alert-<%= message.equals("success") ? "success" : "danger" %>">
            <%= message.equals("success") ? "Payment saved successfully!" : "Payment failed to save." %>
        </div>
        
    <% } %>
    
    <!-- Payment Form -->
    <form action="SavePaymentServlet" method="post">
        <input type="hidden" name="projectId" value="<%= projectId %>">
        <input type="hidden" name="projectName" value="<%= projectName %>">
        
        <div class="mb-3">
            <label for="paymentPhase" class="form-label">Payment Phase:</label>
            <select name="paymentPhase" class="form-select" required>
                <option value="">--Select Phase--</option>
                <option value="Advance">Advance</option>
                <option value="Mid-stage">Mid-stage</option>
                <option value="Before Despatch">Before Despatch</option>
                <option value="After Commissioning">After Commissioning</option>
            </select>
        </div>
        
        <!-- New Percentage Dropdown -->
        <div class="mb-3">
            <label for="percentage" class="form-label">Percentage:</label>
            <select name="percentage" class="form-select" required>
                <option value="">--Select Percentage--</option>
                <option value="5%">5%</option>
                <option value="10%">10%</option>
                <option value="15%">15%</option>
                <option value="20%">20%</option>
                <option value="25%">25%</option>
                <option value="30%">30%</option>
                <option value="35%">35%</option>
                <option value="40%">40%</option>
                <option value="45%">45%</option>
                <option value="50%">50%</option>
            </select>
        </div>
        
        <div class="mb-3">
            <label for="amount" class="form-label">Amount:</label>
            <input type="number" step="0.01" name="amount" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label for="mode" class="form-label">Currency / Mode:</label>
            <select name="mode" class="form-select" required>
                <option value="">--Select--</option>
                <option value="₹">₹</option>
                <option value="$">$</option>
                <option value="£">£</option>
                <option value="€">€</option>
            </select>
        </div>
        
        <div class="mb-3">
            <label for="paymentDate" class="form-label">Payment Date:</label>
            <input type="date" name="paymentDate" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label for="remarks" class="form-label">Remarks / Payment Terms:</label>
            <textarea name="remarks" class="form-control" maxlength="20000"></textarea>
        </div>
        
        <!-- Save Payment Button -->
        <button type="submit" class="btn btn-success">Save Payment</button>
    </form>
    
    <!-- (Optional) Additional buttons or links can go here -->
    
</div>
</body>
</html>
