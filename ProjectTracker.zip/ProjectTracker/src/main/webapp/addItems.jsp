<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Add Items - ProjectTracker</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    .full-width { width: 100% !important; }
    textarea { min-height: 100px; white-space: pre-wrap; }
    table { font-size: 12px; }
    /* Class to simulate disabled select appearance */
    .sim-disabled {
      pointer-events: none;
      background-color: #e9ecef;
    }
  </style>
  <script>
    // Function to check if the SR.No. value indicates a main item.
    // For main items (no dot) we add a CSS class to simulate a disabled select.
    function checkResponsibilityDisabled(srInput) {
      var row = srInput.closest('tr');
      var respSelect = row.querySelector('select[name="responsibility[]"]');
      if (srInput.value.indexOf('.') === -1) {
        // Main item: add class to block interaction
        respSelect.classList.add("sim-disabled");
      } else {
        // Child item: ensure the class is removed
        respSelect.classList.remove("sim-disabled");
      }
    }

    // Function to add a new item row dynamically.
    function addItemRow() {
      var tbody = document.getElementById("itemsTable").getElementsByTagName('tbody')[0];
      var row = tbody.insertRow();
      row.innerHTML = `
        <td>
          <input type="text" name="srNo[]" class="form-control" placeholder="e.g. 1 or 1.1" required onkeyup="checkResponsibilityDisabled(this)">
        </td>
        <td>
          <input type="text" class="form-control" name="erpNo[]" required>
        </td>
        <td>
          <textarea class="form-control" name="itemDescription[]" rows="4" required></textarea>
        </td>
        <td>
          <input type="text" class="form-control" name="capacity[]">
        </td>
        <td>
          <input type="number" class="form-control" name="qty[]" value="0" onchange="calculateRowTotal(this)">
        </td>
        <td>
          <input type="text" class="form-control" name="unitValue[]" value="0" onchange="calculateRowTotal(this)">
        </td>
        <td>
          <input type="text" class="form-control" name="totalValue[]" value="0" readonly>
        </td>
        <td>
          <select class="form-control" name="responsibility[]">
            <option value="">--Select Responsibility--</option>
            <option value="Unit1">Unit1</option>
            <option value="Unit2">Unit2</option>
            <option value="Bought Out">Bought Out</option>
            <option value="Import">Import</option>
          </select>
        </td>
        <td>
          <input type="date" class="form-control" name="plannedDate[]">
        </td>
        <td>
          <input type="date" class="form-control" name="completedDate[]">
        </td>
        <td>
          <button type="button" class="btn btn-danger btn-sm" onclick="deleteItemRow(this)">Delete</button>
        </td>
      `;
    }

    // Function to calculate total = qty * unitValue for a given row.
    function calculateRowTotal(elem) {
      var row = elem.closest('tr');
      var qty = parseFloat(row.querySelector('input[name="qty[]"]').value) || 0;
      var unitValStr = row.querySelector('input[name="unitValue[]"]').value.replace(/,/g, '');
      var unitValue = parseFloat(unitValStr) || 0;
      var total = qty * unitValue;
      row.querySelector('input[name="unitValue[]"]').value = formatNumber(unitValue);
      row.querySelector('input[name="totalValue[]"]').value = formatNumber(total);
    }

    // Function to format a number with commas (no decimals).
    function formatNumber(num) {
      return parseInt(num).toLocaleString('en-US');
    }

    // Function to delete an item row.
    function deleteItemRow(btn) {
      var row = btn.closest('tr');
      row.parentNode.removeChild(row);
    }

    // Before form submission, remove commas from numeric fields.
    function removeCommasBeforeSubmit() {
      var unitFields = document.getElementsByName("unitValue[]");
      for (var i = 0; i < unitFields.length; i++) {
        unitFields[i].value = unitFields[i].value.replace(/,/g, '');
      }
      var totalFields = document.getElementsByName("totalValue[]");
      for (var i = 0; i < totalFields.length; i++) {
        totalFields[i].value = totalFields[i].value.replace(/,/g, '');
      }
      return true;
    }
  </script>
</head>
<body>
<div class="container-fluid">
  <h2>Add Items for Project</h2>
  <% 
      // Retrieve the project ID from the request parameter.
      String projectId = request.getParameter("projectId");
  %>
  <p>Project ID: <strong><%= projectId %></strong></p>
  <!-- The form below submits all item rows to the AddItemsServlet -->
  <form action="addItems" method="post" onsubmit="return removeCommasBeforeSubmit();">
    <input type="hidden" name="projectId" value="<%= projectId %>">
    <table class="table table-bordered full-width" id="itemsTable">
      <thead class="table-dark">
        <tr>
          <th>SR.No.</th>
          <th>ERP No.</th>
          <th>Item Description</th>
          <th>Capacity</th>
          <th>Qty</th>
          <th>Unit Value</th>
          <th>Total Value</th>
          <th>Responsibility</th>
          <th>Planned Date</th>
          <th>Completed Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <!-- Initially, no rows; click "Add Item" to create rows dynamically -->
      </tbody>
    </table>
    <button type="button" class="btn btn-info" onclick="addItemRow()">Add Item</button>
    <br/><br/>
    <button type="submit" class="btn btn-primary">Save All Items</button>
    <a href="viewItems?projectId=<%= projectId %>" class="btn btn-secondary">Cancel</a>
    <hr>
  </form>
</div>
</body>
</html>
