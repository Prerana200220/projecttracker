<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Add New Project - ProjectTracker</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    .full-width { width: 100% !important; }
    textarea { min-height: 100px; white-space: pre-wrap; }
  </style>
  <script>
    // ----- Dropdown "Add More" function -----
    function handleAddMore(selectElem) {
      if (selectElem.value === "AddMore") {
        var newValue = prompt("Enter new " + selectElem.name + ":");
        if (newValue && newValue.trim() !== "") {
          var option = document.createElement("option");
          option.value = newValue;
          option.text = newValue;
          var addMoreOption = selectElem.querySelector('option[value="AddMore"]');
          selectElem.insertBefore(option, addMoreOption);
          selectElem.value = newValue;
        } else {
          selectElem.value = "";
        }
      }
    }

    // ----- Formatting Functions for Numbers -----
    // Format a number (with no decimals) with commas
    function formatNumber(num) {
      return Number(num).toLocaleString('en-US', { maximumFractionDigits: 0 });
    }

    // Format the project value field on blur
    function formatProjectValue() {
      var input = document.getElementById("projectValue");
      var value = input.value.replace(/,/g, '');
      if (value) {
        var num = Number(value);
        if (!isNaN(num)) {
          input.value = formatNumber(num);
        }
      }
    }

    // (Optional) Format an item unit value field on blur
    function formatItemValue(elem) {
      var value = elem.value.replace(/,/g, '');
      if (value) {
        var num = Number(value);
        if (!isNaN(num)) {
          elem.value = formatNumber(num);
        }
      }
    }

    // Before form submission, remove commas from numeric fields
    function removeCommasBeforeSubmit() {
      // Remove commas from the project value field
      var projInput = document.getElementById("projectValue");
      projInput.value = projInput.value.replace(/,/g, '');
      
      // Optionally, remove commas from each item unit value field if they are type text:
      var unitValueInputs = document.querySelectorAll('input[name="unitValue[]"]');
      unitValueInputs.forEach(function(input) {
        input.value = input.value.replace(/,/g, '');
      });
      return true;
    }

    // ----- Item Row Functions -----
    function addItemRow() {
      var tbody = document.getElementById("itemsTable").getElementsByTagName('tbody')[0];
      var rowCount = tbody.rows.length;
      var row = tbody.insertRow(rowCount);
      row.innerHTML = `
        <td>${rowCount + 1}</td>
        <td><input type="text" class="form-control" name="erpNo[]" required></td>
        <td><textarea class="form-control" name="itemDescription[]" rows="4" required></textarea></td>
        <td><input type="text" class="form-control" name="capacity[]"></td>
        <td><input type="number" class="form-control" name="qty[]" value="0" onchange="calculateRowTotal(this)"></td>
        <td>
          <!-- Use type="text" for unit value so we can format it with commas -->
          <input type="text" class="form-control" name="unitValue[]" value="0" onblur="formatItemValue(this)" onchange="calculateRowTotal(this)">
        </td>
        <td>
          <!-- totalValue is read-only and will be calculated -->
          <input type="text" class="form-control" name="totalValue[]" value="0" readonly>
        </td>
        <td>
          <select class="form-control" name="responsibility[]">
            <option value="Unit1">Unit1</option>
            <option value="Unit2">Unit2</option>
            <option value="Bought Out">Bought Out</option>
            <option value="Import">Import</option>
          </select>
        </td>
        <td><input type="date" class="form-control" name="plannedDate[]"></td>
        <td><input type="date" class="form-control" name="completedDate[]"></td>
        <td>
          <button type="button" class="btn btn-danger btn-sm" onclick="deleteItemRow(this)">Delete</button>
        </td>
      `;
    }

    function calculateRowTotal(elem) {
      var row = elem.closest('tr');
      // Remove commas from the unit value if present
      var unitInput = row.querySelector('input[name="unitValue[]"]');
      var unitValueRaw = unitInput.value.replace(/,/g, '');
      var qty = parseFloat(row.querySelector('input[name="qty[]"]').value) || 0;
      var unitValue = parseFloat(unitValueRaw) || 0;
      var total = qty * unitValue;
      var totalField = row.querySelector('input[name="totalValue[]"]');
      totalField.value = formatNumber(total);
    }
    
    // Function to edit an individual item row via Ajax.
    function editItemRow(btn) {
        var row = btn.closest('tr');
        var itemId = row.getAttribute('data-item-id');
        if (!itemId) {
            alert("This item has not been saved yet. Please save it first.");
            return;
        }
        var erpNo = row.querySelector('input[name="erpNo[]"]').value;
        var itemDescription = row.querySelector('textarea[name="itemDescription[]"]').value;
        var capacity = row.querySelector('input[name="capacity[]"]').value;
        var qty = row.querySelector('input[name="qty[]"]').value;
        var unitInput = row.querySelector('input[name="unitValue[]"]');
        var unitValue = unitInput.value.replace(/,/g, '');
        var responsibility = row.querySelector('select[name="responsibility[]"]').value;
        var plannedDate = row.querySelector('input[name="plannedDate[]"]').value;
        var completedDate = row.querySelector('input[name="completedDate[]"]').value;
        var projectId = document.getElementById("projectId").value;

        var formData = new FormData();
        formData.append("itemId", itemId);
        formData.append("erpNo", erpNo);
        formData.append("itemDescription", itemDescription);
        formData.append("capacity", capacity);
        formData.append("qty", qty);
        formData.append("unitValue", unitValue);
        formData.append("responsibility", responsibility);
        formData.append("plannedDate", plannedDate);
        formData.append("completedDate", completedDate);
        formData.append("projectId", projectId);

        fetch("editItem", {
            method: "POST",
            body: formData
        })
        .then(function(response) {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.text();
        })
        .then(function(data) {
            alert("Item updated successfully: " + data);
        })
        .catch(function(error) {
            alert("Error updating item: " + error);
        });
    }

    // Ajax function to save an individual item row.
    function saveItemRow(btn) {
      var row = btn.closest('tr');
      var erpNo = row.querySelector('input[name="erpNo[]"]').value;
      var itemDescription = row.querySelector('textarea[name="itemDescription[]"]').value;
      var capacity = row.querySelector('input[name="capacity[]"]').value;
      var qty = row.querySelector('input[name="qty[]"]').value;
      var unitValue = row.querySelector('input[name="unitValue[]"]').value.replace(/,/g, '');
      var responsibility = row.querySelector('select[name="responsibility[]"]').value;
      var plannedDate = row.querySelector('input[name="plannedDate[]"]').value;
      var completedDate = row.querySelector('input[name="completedDate[]"]').value;
      var projectId = document.getElementById("projectId").value;
      
      var formData = new FormData();
      formData.append("projectId", projectId);
      formData.append("erpNo", erpNo);
      formData.append("itemDescription", itemDescription);
      formData.append("capacity", capacity);
      formData.append("qty", qty);
      formData.append("unitValue", unitValue);
      formData.append("responsibility", responsibility);
      formData.append("plannedDate", plannedDate);
      formData.append("completedDate", completedDate);
      
      fetch("saveItem", {
        method: "POST",
        body: formData
      })
      .then(function(response) {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.text();
      })
      .then(function(data) {
        alert("Item saved: " + data);
      })
      .catch(function(error) {
        alert("Error saving item: " + error);
      });
    }

    function deleteItemRow(btn) {
        if (confirm("Are you sure you want to delete this item?")) {
            var row = btn.closest('tr');
            row.parentNode.removeChild(row);
            var rows = document.getElementById("itemsTable").getElementsByTagName('tbody')[0].rows;
            for (var i = 0; i < rows.length; i++) {
                rows[i].cells[0].innerHTML = i + 1;
            }
        }
    }
  </script>
</head>
<body>
<div class="container-fluid">
  <h2>Add New Project</h2>
  <!-- Combined form for project and items -->
  <form action="addProjectWithItems" method="post" onsubmit="return removeCommasBeforeSubmit();">
    <!-- Project details -->
    <div class="row mb-3">
      <div class="col">
        <label>Job No.</label>
        <input type="text" name="jobNo" class="form-control" required>
      </div>
      <div class="col">
        <label>Customer</label>
        <input type="text" name="customer" class="form-control" required>
      </div>
      <div class="col">
        <label>City</label>
        <input type="text" name="city" class="form-control" required>
      </div>
    </div>
    <div class="row mb-3">
      <div class="col">
        <label>Region</label>
        <select name="region" class="form-control" onchange="handleAddMore(this)">
          <option value="North">North</option>
          <option value="East">East</option>
          <option value="West">West</option>
          <option value="South">South</option>
          <option value="Export">Export</option>
          <option value="AddMore">Add More</option>
        </select>
      </div>
      <div class="col">
        <label>Segment</label>
        <select name="segment" class="form-control" onchange="handleAddMore(this)">
          <option value="Beverage">Beverage</option>
          <option value="Dairy">Dairy</option>
          <option value="Prepared Food">Prepared Food</option>
          <option value="Equipment">Equipment</option>
          <option value="AddMore">Add More</option>
        </select>
      </div>
      <div class="col">
        <label>Project Manager</label>
        <select name="projectManager" class="form-control" onchange="handleAddMore(this)">
          <option value="Rohit BR">Rohit BR</option>
          <option value="Nitin Chede">Nitin Chede</option>
          <option value="Jitendra Koli">Jitendra Koli</option>
          <option value="Vignesh NPN">Vignesh NPN</option>
          <option value="AddMore">Add More</option>
        </select>
      </div>
    </div>
    <div class="mb-3">
      <label>Project Name</label>
      <input type="text" name="projectName" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Project Value (in INR)</label>
      <input type="text" name="projectValue" id="projectValue" class="form-control" onblur="formatProjectValue()" required>
    </div>
    <div class="mb-3">
      <label>Currency for Display</label>
      <select name="currency" class="form-control" required>
        <option value="INR">INR</option>
        <option value="USD">USD</option>
        <option value="UKP">UKP</option>
      </select>
      <small class="form-text text-muted">
        Enter the project value in INR. The selected currency will be used for display conversion.
      </small>
    </div>
    <!-- New Fields for Payment Terms and Customer Required Date -->
    <div class="row mb-3">
      <div class="col">
        <label>Payment Terms</label>
        <input type="text" name="paymentTerms" class="form-control">
      </div>
      <div class="col">
        <label>Customer Required Date</label>
        <input type="date" name="customerRequiredDate" class="form-control">
      </div>
    </div>
    <button type="submit" class="btn btn-success">Save Project</button>
    
    <hr>
    <!-- Items Section
    <h3>Items for This Project (Demo Section)</h3>
    <table class="table table-bordered full-width" id="itemsTable">
      <thead class="table-dark">
        <tr>
          <th>Sr.No.</th>
          <th>ERP No.</th>
          <th>Item Description</th>
          <th>Capacity</th>
          <th>Qty</th>
          <th>Unit Value</th>
          <th>Total Value</th>
          <th>Responsibility</th>
          <th>Planned Date</th>
          <th>Completed Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <!-- Dynamic item rows will be added here 
      </tbody>
    </table>
    <button type="button" class="btn btn-info" onclick="addItemRow()">Add Item</button>
    <br/><br/>
    <button type="submit" class="btn btn-primary">Save All Items and Project</button> -->
  </form>
</div>
</body>
</html>
