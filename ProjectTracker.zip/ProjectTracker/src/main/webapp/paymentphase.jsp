<%@ page import="java.util.*, java.text.SimpleDateFormat, java.text.DecimalFormat, com.example.PaymentReceipt, com.example.PaymentReceiptDAO" %> 
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Retrieve projectId and projectName from request parameters
    String projParam = request.getParameter("projectId");
    String projectName = request.getParameter("projectName");

    // Ensure both parameters are provided
    if (projParam == null || projParam.trim().isEmpty() ||
        projectName == null || projectName.trim().isEmpty()) {
%>
    <div class="alert alert-danger">
        Project ID or Project Name not provided.
    </div>
<%
        return;
    }
    
    int projectId = Integer.parseInt(projParam);
    String message = request.getParameter("message");
    
    // Fetch payments for this project
    PaymentReceiptDAO dao = new PaymentReceiptDAO();
    List<PaymentReceipt> payments = dao.getPaymentsByProject(projectId);
    
    // DecimalFormat for amount (e.g., 300,000.00)
    DecimalFormat amountFormat = new DecimalFormat("#,###.##");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Phase for <%= projectName %></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Include Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body {
            font-family: Arial, sans-serif;  /* uniform font */
            font-size: 14px;                 /* uniform font size */
            background-color: #ffffff;       /* white background */
        }
        /* Use a smaller heading for the title */
        .page-title {
            color: black;
            font-size: 18px;
            margin: 0;
        }
        /* Style table header with black background and white text */
        thead th {
            background-color: black !important;
            color: #fff !important;
        }
    </style>
    <script>
        function confirmDelete(receiptId) {
            return confirm("Are you sure you want to delete this payment?");
        }
    </script>
</head>
<body>
<div class="container mt-4">
    <!-- Row with Title on the left and buttons on the right -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="page-title">
            Payment Records for <%= projectName %>
        </h3>
        <div>
            <!-- Add Payment Receipt Button -->
            <a href="receipt_of_payment.jsp?projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>" 
               class="btn btn-primary btn-sm me-2" title="Add Payment Receipt">
               <i class="bi bi-plus-circle"></i> Add Payment
            </a>
            <!-- Dashboard Button -->
            <a href="dashboard" 
               class="btn btn-secondary btn-sm" title="Back to Dashboard">
               <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>
    
    <!-- Display message if any -->
    <% if(message != null) { %>
        <div class="alert alert-<%= message.equals("success") ? "success" : "danger" %>">
            <%= message.equals("success") ? "Payment saved successfully!" : "Payment failed to save." %>
        </div>
    <% } %>
    
    <!-- Payment Records Table -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Payment Phase ID</th>
                <th>Payment Phase</th>
                <th>Percentage</th>
                <th>Amount</th>
                <th>Mode</th>
                <th>Payment Date</th>
                <th>Remarks</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <%
                // Set up date conversion: from "yyyy-MM-dd" to "dd-MM-yyyy"
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
                for (PaymentReceipt r : payments) {
                    String rawDate = r.getPaymentDate();
                    String formattedDate = "";
                    if (rawDate != null && !rawDate.trim().isEmpty()) {
                        try {
                            Date dateObj = inputFormat.parse(rawDate);
                            formattedDate = outputFormat.format(dateObj);
                        } catch (Exception e) {
                            formattedDate = rawDate; // Fallback if parsing fails
                        }
                    }
            %>
            <tr>
                <td><%= r.getId() %></td>
                <td><%= r.getPaymentPhase() %></td>
                <td><%= r.getPercentage() %></td>
                <td><%= amountFormat.format(r.getAmount()) %></td>
                <td><%= r.getMode() %></td>
                <td><%= formattedDate %></td>
                <td><%= r.getRemarks() %></td>
                <td>
                    <!-- Edit Button -->
                    <a href="editPaymentReceipt.jsp?receiptId=<%= r.getId() %>&projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>"
                       class="btn btn-warning btn-sm" title="Edit Payment">
                        <i class="bi bi-pencil-square"></i> Edit
                    </a>
                    <!-- Delete Button -->
                    <a href="deletePaymentReceipt?receiptId=<%= r.getId() %>&projectId=<%= projectId %>&projectName=<%= java.net.URLEncoder.encode(projectName, "UTF-8") %>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirmDelete(<%= r.getId() %>);"
                       title="Delete Payment">
                        <i class="bi bi-trash"></i> Delete
                    </a>
                </td>
            </tr>
            <%
                }
            %>
        </tbody>
    </table>
</div>
</body>
</html>
