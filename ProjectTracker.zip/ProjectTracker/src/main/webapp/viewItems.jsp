<%@ page contentType="text/html;charset=UTF-8" language="java" %> 
<%@ page import="java.util.*, java.text.*" %>
<%@ page import="com.example.Project" %>
<%@ page import="com.example.Item" %>
<%@ page import="com.example.ProjectDAO" %>

<%
    // Setup formatters
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    DecimalFormat df = new DecimalFormat("#,###");

    // Current date/time
    Date today = new Date();

    // We'll use a Calendar to represent "today" (only year/month/day)
    Calendar calToday = Calendar.getInstance();
    calToday.setTime(today);

    // Retrieve project and items
    Project project = (Project) request.getAttribute("project");
    List<Item> items = (List<Item>) request.getAttribute("items");

    // If project is null, try loading from request parameter
    if (project == null) {
        String projectIdStr = request.getParameter("projectId");
        if (projectIdStr != null && !projectIdStr.isEmpty()) {
            int projectId = Integer.parseInt(projectIdStr);
            ProjectDAO projectDao = new ProjectDAO();
            project = projectDao.getProjectById(projectId);
        }
    }

    // Get user role (default to "user")
    String role = (String) session.getAttribute("userRole");
    if (role == null) {
        role = "user";
    }

    // Handle search query
    String searchQuery = request.getParameter("search");
    if (searchQuery == null) {
        searchQuery = "";
    }
    searchQuery = searchQuery.trim().toLowerCase();

    // Filter items based on search
    List<Item> filteredItems = new ArrayList<>();
    if (items != null) {
        for (Item it : items) {
            boolean matchesSearch = true; // default if no search
            if (!searchQuery.isEmpty()) {
                // Convert fields to string and check if they contain the query
                String erp = (it.getErpNo() != null) ? it.getErpNo().toLowerCase() : "";
                String desc = (it.getItemDescription() != null) ? it.getItemDescription().toLowerCase() : "";
                String cap = (it.getCapacity() != null) ? it.getCapacity().toLowerCase() : "";
                String resp = (it.getResponsibility() != null) ? it.getResponsibility().toLowerCase() : "";
                String delay = (it.getDelayReason() != null) ? it.getDelayReason().toLowerCase() : "";
                String status = (it.getStatus() != null) ? it.getStatus().toLowerCase() : "";

                // Format dates for searching
                String plannedDateStr = (it.getPlannedDate() != null) ? sdf.format(it.getPlannedDate()).toLowerCase() : "";
                String completedDateStr = (it.getCompletedDate() != null) ? sdf.format(it.getCompletedDate()).toLowerCase() : "";
                String readyByStr = (it.getReadyBy() != null) ? sdf.format(it.getReadyBy()).toLowerCase() : "";

                // Build a quick "contains" check
                matchesSearch = (
                      erp.contains(searchQuery)
                   || desc.contains(searchQuery)
                   || cap.contains(searchQuery)
                   || (""+it.getQty()).contains(searchQuery)
                   || (""+it.getUnitValue()).contains(searchQuery)
                   || (""+it.getTotalValue()).contains(searchQuery)
                   || resp.contains(searchQuery)
                   || plannedDateStr.contains(searchQuery)
                   || completedDateStr.contains(searchQuery)
                   || delay.contains(searchQuery)
                   || status.contains(searchQuery)
                   || readyByStr.contains(searchQuery)
                );
            }
            if (matchesSearch) {
                filteredItems.add(it);
            }
        }
    }

    // Check if any item is planned for today to show a message
    boolean showPlannedTodayMessage = false;
    for (Item item : filteredItems) {
        Date pDate = item.getPlannedDate();
        if (pDate != null) {
            Calendar calItem = Calendar.getInstance();
            calItem.setTime(pDate);
            boolean sameDay = (calToday.get(Calendar.YEAR) == calItem.get(Calendar.YEAR)
                && calToday.get(Calendar.DAY_OF_YEAR) == calItem.get(Calendar.DAY_OF_YEAR));
            if (sameDay) {
                showPlannedTodayMessage = true;
                break;
            }
        }
    }

    // Group items by srNo (main vs. child), also apply role-based filtering
    Map<String, List<Item>> childItemsMap = new HashMap<>();
    List<Item> mainItems = new ArrayList<>();
    if (filteredItems != null) {
        for (Item item : filteredItems) {
            // Role-based filtering:
            // - admin, unit1, unit2, purchase (or purchases) have authority over items.
            // - user can view all items.
            boolean show = false;
            if (role.equalsIgnoreCase("admin")) {
                show = true;
            } else if (role.equalsIgnoreCase("unit1") && "Unit1".equalsIgnoreCase(item.getResponsibility())) {
                show = true;
            } else if (role.equalsIgnoreCase("unit2") && "Unit2".equalsIgnoreCase(item.getResponsibility())) {
                show = true;
            } else if ((role.equalsIgnoreCase("purchase") || role.equalsIgnoreCase("purchases"))
                        && item.getResponsibility() != null &&
                        (item.getResponsibility().equalsIgnoreCase("Bought Out") 
                         || item.getResponsibility().equalsIgnoreCase("Import"))) {
                show = true;
            } else if (role.equalsIgnoreCase("user")) {
                show = true;
            }
            if (!show) {
                continue;
            }
            // Optionally skip completed items
            if (item.getCompletedDate() != null) {
                continue;
            }
            // Group by srNo
            String sr = item.getSrNo();
            if (sr != null && sr.contains(".")) {
                // child item
                String mainSerial = sr.substring(0, sr.indexOf('.'));
                childItemsMap.computeIfAbsent(mainSerial, k -> new ArrayList<>()).add(item);
            } else {
                // main item
                mainItems.add(item);
            }
        }
    }
%>

<% if (project == null) { %>
    <h3>Project not found!</h3>
<% } else { %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Items for Project - <%= project.getProjectName() %></title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        /* Header row */
        .header-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            flex-wrap: nowrap;
            gap: 10px;
        }
        .project-title {
            max-width: 70%;
            word-wrap: break-word;
            margin: 0;
            line-height: 1.2;
        }
        .header-right a {
            font-size: 28px;
            color: #333;
            text-decoration: none;
        }
        .header-right a:hover {
            color: #007bff;
        }
        /* Table formatting */
        .full-screen-table {
            width: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        .table thead th {
            font-size: 0.8rem !important;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
        }
        .table tbody td {
            vertical-align: middle;
        }
        .desc-col {
            width: 20%;
            text-align: left !important;
        }
        .desc-cell {
            text-align: left !important;
            white-space: normal;
            word-break: break-word;
            margin: 0 !important;
            padding: 4px !important;
        }
        .status-col {
            width: 5%;
            text-align: center !important;
            white-space: nowrap;
        }
        .status-cell {
            text-align: center !important;
            white-space: normal;
            margin: 0 !important;
            padding: 4px !important;
        }
        .text-right {
            text-align: right !important;
            white-space: nowrap;
        }
        .nowrap {
            white-space: nowrap !important;
        }
        .delay-cell {
            text-align: center !important;
            padding-right: 0 !important;
            padding-left: 4px !important;
        }
        .btn {
            font-size: 0.875rem !important;
            padding: 4px 8px !important;
            margin: 2px !important;
        }
        .clickable {
            cursor: pointer;
        }
        .table thead {
            position: sticky;
            top: 0;
            z-index: 1020;
            background-color: black;
            color: white;
        }
        /* Alert message style */
        .alert-planned {
            color: red;
            font-weight: bold;
            padding: 10px;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
    <script>
        // Toggle display of child rows for the given main serial number.
        function toggleChildRows(mainSerial) {
            var childRows = document.getElementsByClassName("child-" + mainSerial);
            for (var i = 0; i < childRows.length; i++) {
                if (childRows[i].style.display === "none" || childRows[i].style.display === "") {
                    childRows[i].style.display = "table-row";
                } else {
                    childRows[i].style.display = "none";
                }
            }
        }
    </script>
</head>
<body>
<div class="container-fluid mt-3">
    <!-- Header row with project name and navigation buttons -->
    <div class="header-row">
        <h2 class="project-title">
            <i class="bi bi-list-ul"></i> Items for Project: <%= project.getProjectName() %>
        </h2>
        <div class="header-right">
            <%-- Show "Add Items" link only for admin --%>
            <% if (role.equalsIgnoreCase("admin")) { %>
                <a href="addItems.jsp?projectId=<%= project.getId() %>" title="Add Items">
                    <i class="bi bi-plus-circle"></i>
                </a>
            <% } %>
            <a href="dashboard" title="Back to Dashboard">
                <i class="bi bi-house"></i>
            </a>
        </div>
    </div>
    <!-- Search field -->
    <div class="d-flex justify-content-end mb-3">
        <form action="viewItems" method="get" class="d-flex">
            <input type="hidden" name="projectId" value="<%= project.getId() %>">
            <input type="text" name="search" class="form-control form-control-sm me-2" 
                   placeholder="Search items..."
                   value='<%= request.getParameter("search") != null ? request.getParameter("search") : "" %>'>
            <button type="submit" class="btn btn-outline-primary btn-sm">Search</button>
        </form>
    </div>

    <!-- Alert message if some items are planned for today -->
    <% if (showPlannedTodayMessage) { %>
        <div class="alert-planned">
            Some items are planned for today!
        </div>
    <% } %>

    <!-- Items Table -->
    <table class="table table-bordered full-screen-table">
        <thead class="table-dark">
            <tr>
                <th>Sr.No.</th>
                <th>ERP No.</th>
                <th class="desc-col">Item Description</th>
                <th>Capacity</th>
                <th>Qty</th>
                <th class="text-right nowrap">Unit Value</th>
                <th class="text-right nowrap">Total Value</th>
                <th>Responsibility</th>
                <th>Planned Date</th>
                <th>Completed Date</th>
                <th class="text-center" style="padding-right:0;">Reason for Delay</th>
                <th class="status-col">Status</th>
                <th>Ready By</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <%
           // Render main (header) items
           for (Item mainItem : mainItems) {
               // Check if mainItem planned date == today
               boolean isPlannedToday = false;
               if (mainItem.getPlannedDate() != null) {
                   Calendar calItem = Calendar.getInstance();
                   calItem.setTime(mainItem.getPlannedDate());
                   isPlannedToday = (calToday.get(Calendar.YEAR) == calItem.get(Calendar.YEAR)
                                    && calToday.get(Calendar.DAY_OF_YEAR) == calItem.get(Calendar.DAY_OF_YEAR));
               }
               // If planned for today, set inline style to highlight in red
               String redStyle = isPlannedToday ? "color:red;font-weight:bold;" : "";
               String mainSerial = mainItem.getSrNo();
        %>
            <tr class="clickable" onclick="toggleChildRows('<%= mainSerial %>')">
                <td class="text-center" style="<%= redStyle %>"><%= mainItem.getSrNo() %></td>
                <td class="text-center" style="<%= redStyle %>"><%= mainItem.getErpNo() %></td>
                <td class="desc-cell" style="<%= redStyle %>"><%= mainItem.getItemDescription() %></td>
                <td class="text-center" style="<%= redStyle %>"><%= mainItem.getCapacity() %></td>
                <td class="text-center" style="<%= redStyle %>"><%= mainItem.getQty() %></td>
                <td class="text-right nowrap" style="<%= redStyle %>">
                    <%= df.format(mainItem.getUnitValue()) %>
                </td>
                <td class="text-right nowrap" style="<%= redStyle %>">
                    <%= df.format(mainItem.getTotalValue()) %>
                </td>
                <td class="text-center" style="<%= redStyle %>">
                    <%= (mainItem.getResponsibility() != null && !mainItem.getResponsibility().trim().isEmpty())
                         ? mainItem.getResponsibility() : "-" %>
                </td>
                <td class="text-center nowrap" style="<%= redStyle %>">
                    <%= (mainItem.getPlannedDate() != null) ? sdf.format(mainItem.getPlannedDate()) : "-" %>
                </td>
                <td class="text-center nowrap" style="<%= redStyle %>">
                    <%= (mainItem.getCompletedDate() != null) ? sdf.format(mainItem.getCompletedDate()) : "-" %>
                </td>
                <td class="delay-cell" style="<%= redStyle %>">
                    <%= (mainItem.getDelayReason() != null && !mainItem.getDelayReason().trim().isEmpty())
                         ? mainItem.getDelayReason() : "-" %>
                </td>
                <td class="text-center" style="<%= redStyle %>">
                    <%= (mainItem.getStatus() != null && !mainItem.getStatus().trim().isEmpty())
                         ? mainItem.getStatus() : "-" %>
                </td>
                <td class="text-center nowrap" style="<%= redStyle %>">
                    <%= (mainItem.getReadyBy() != null) ? sdf.format(mainItem.getReadyBy()) : "-" %>
                </td>
                <td class="text-center" style="<%= redStyle %>">
                    <% 
                        // Action links based on role:
                        // - Admin: full access (edit and delete)
                        // - Unit1, Unit2, Purchase/Purchases: restricted edit
                        // - User: no action link.
                        if (role.equalsIgnoreCase("admin")) { 
                    %>
                        <a href="editItem?itemId=<%= mainItem.getId() %>&projectId=<%= project.getId() %>"
                           class="btn btn-warning btn-sm" title="Edit Item">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="deleteItem?itemId=<%= mainItem.getId() %>&projectId=<%= project.getId() %>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this item?');"
                           title="Delete Item">
                            <i class="bi bi-trash"></i>
                        </a>
                    <% } else if (role.equalsIgnoreCase("unit1") || role.equalsIgnoreCase("unit2") ||
                              role.equalsIgnoreCase("purchase") || role.equalsIgnoreCase("purchases")) { %>
                        <a href="editRestrictedItem?itemId=<%= mainItem.getId() %>&projectId=<%= project.getId() %>"
                           class="btn btn-warning btn-sm" title="Edit Status & Ready By">
                            <i class="bi bi-pencil"></i>
                        </a>
                    <% } %>
                </td>
            </tr>
            <%
               // Render child items
               List<Item> childItems = childItemsMap.get(mainSerial);
               if (childItems != null) {
                   for (Item child : childItems) {
                       boolean childPlannedToday = false;
                       if (child.getPlannedDate() != null) {
                           Calendar calChild = Calendar.getInstance();
                           calChild.setTime(child.getPlannedDate());
                           childPlannedToday = (calToday.get(Calendar.YEAR) == calChild.get(Calendar.YEAR)
                                              && calToday.get(Calendar.DAY_OF_YEAR) == calChild.get(Calendar.DAY_OF_YEAR));
                       }
                       String childRedStyle = childPlannedToday ? "color:red;font-weight:bold;" : "";
            %>
            <tr class="childRow child-<%= mainSerial %>" style="display: none;">
                <td class="text-center" style="<%= childRedStyle %>"><%= child.getSrNo() %></td>
                <td class="text-center" style="<%= childRedStyle %>"><%= child.getErpNo() %></td>
                <td class="desc-cell" style="<%= childRedStyle %>"><%= child.getItemDescription() %></td>
                <td class="text-center" style="<%= childRedStyle %>"><%= child.getCapacity() %></td>
                <td class="text-center" style="<%= childRedStyle %>"><%= child.getQty() %></td>
                <td class="text-right nowrap" style="<%= childRedStyle %>">
                    <%= df.format(child.getUnitValue()) %>
                </td>
                <td class="text-right nowrap" style="<%= childRedStyle %>">
                    <%= df.format(child.getTotalValue()) %>
                </td>
                <td class="text-center" style="<%= childRedStyle %>">
                    <%= (child.getResponsibility() != null && !child.getResponsibility().trim().isEmpty())
                         ? child.getResponsibility() : "-" %>
                </td>
                <td class="text-center nowrap" style="<%= childRedStyle %>">
                    <%= (child.getPlannedDate() != null) ? sdf.format(child.getPlannedDate()) : "-" %>
                </td>
                <td class="text-center nowrap" style="<%= childRedStyle %>">
                    <%= (child.getCompletedDate() != null) ? sdf.format(child.getCompletedDate()) : "-" %>
                </td>
                <td class="delay-cell" style="<%= childRedStyle %>">
                    <%= (child.getDelayReason() != null && !child.getDelayReason().trim().isEmpty())
                         ? child.getDelayReason() : "-" %>
                </td>
                <td class="text-center" style="<%= childRedStyle %>">
                    <%= (child.getStatus() != null && !child.getStatus().trim().isEmpty())
                         ? child.getStatus() : "-" %>
                </td>
                <td class="text-center nowrap" style="<%= childRedStyle %>">
                    <%= (child.getReadyBy() != null) ? sdf.format(child.getReadyBy()) : "-" %>
                </td>
                <td class="text-center" style="<%= childRedStyle %>">
                    <% if (role.equalsIgnoreCase("admin")) { %>
                        <a href="editItem?itemId=<%= child.getId() %>&projectId=<%= project.getId() %>"
                           class="btn btn-warning btn-sm" title="Edit Item">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="deleteItem?itemId=<%= child.getId() %>&projectId=<%= project.getId() %>"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this item?');"
                           title="Delete Item">
                            <i class="bi bi-trash"></i>
                        </a>
                    <% } else if (role.equalsIgnoreCase("unit1") || role.equalsIgnoreCase("unit2") ||
                              role.equalsIgnoreCase("purchase") || role.equalsIgnoreCase("purchases")) { %>
                        <a href="editRestrictedItem?itemId=<%= child.getId() %>&projectId=<%= project.getId() %>"
                           class="btn btn-warning btn-sm" title="Edit Status & Ready By">
                            <i class="bi bi-pencil"></i>
                        </a>
                    <% } %>
                </td>
            </tr>
            <%
                   }
               }
           }
        %>
        </tbody>
    </table>
</div>
</body>
</html>
<% } %>
