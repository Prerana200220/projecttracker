<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.example.Item" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    // Retrieve the item (set by the servlet)
    Item item = (Item) request.getAttribute("item");
    if (item == null) {
        out.println("<h3>Item not found.</h3>");
        return;
    }
    
    // Retrieve projectId (set by the servlet)
    int projectId = (Integer) request.getAttribute("projectId");
    
    // Retrieve the logged-in user's role from session
    String role = (String) session.getAttribute("userRole");
    if (role == null) {
        role = "user";
    }
    
    // Apply role-based filtering:
    // - Admins are not allowed here (they should use the full edit page).
    // - Unit1 users can only edit items with responsibility "Unit1".
    // - Unit2 users can only edit items with responsibility "Unit2".
    // - Purchase users can only edit items with responsibility "Bought Out" or "Import".
    boolean allowed = false;
    if (role.equalsIgnoreCase("admin")) {
        out.println("<h3>Admins must use the full edit page.</h3>");
        return;
    } else if (role.equalsIgnoreCase("unit1")) {
        if (item.getResponsibility() != null && item.getResponsibility().equalsIgnoreCase("Unit1")) {
            allowed = true;
        }
    } else if (role.equalsIgnoreCase("unit2")) {
        if (item.getResponsibility() != null && item.getResponsibility().equalsIgnoreCase("Unit2")) {
            allowed = true;
        }
    } else if (role.equalsIgnoreCase("purchase") || role.equalsIgnoreCase("purchases")) {
        if (item.getResponsibility() != null &&
           (item.getResponsibility().equalsIgnoreCase("Bought Out") ||
            item.getResponsibility().equalsIgnoreCase("Import"))) {
            allowed = true;
        }
    }
    
    if (!allowed) {
        out.println("<h3>You are not authorized to edit this item.</h3>");
        return;
    }
    
    // Formatter for HTML5 date inputs (ISO format)
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Restricted Item - <%= item.getItemDescription() %></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <script>
    function validateForm(){
      // Add client-side validations if needed
      return true;
    }
  </script>
</head>
<body>
<div class="container mt-3">
  <h2>Edit Restricted Item</h2>
  <form action="updateRestrictedItem" method="post" onsubmit="return validateForm();">
    <!-- Hidden fields to pass IDs -->
    <input type="hidden" name="itemId" value="<%= item.getId() %>">
    <input type="hidden" name="projectId" value="<%= projectId %>">
    
    <!-- Display non-editable fields -->
    <div class="mb-3">
      <label>ERP No.</label>
      <input type="text" name="erpNo" class="form-control" value="<%= item.getErpNo() %>" readonly>
    </div>
    <div class="mb-3">
      <label>Item Description</label>
      <textarea name="itemDescription" class="form-control" rows="3" readonly><%= item.getItemDescription() %></textarea>
    </div>
    
    <!-- Editable fields: Only Status and Ready By -->
    <div class="mb-3">
      <label>Status</label>
      <select name="status" class="form-select">
        <option value="delay" <%= "delay".equalsIgnoreCase(item.getStatus()) ? "selected" : "" %>>Delay</option>
        <option value="onTime" <%= "onTime".equalsIgnoreCase(item.getStatus()) ? "selected" : "" %>>On Time</option>
        <option value="early" <%= "early".equalsIgnoreCase(item.getStatus()) ? "selected" : "" %>>Early</option>
      </select>
    </div>
    <div class="mb-3">
      <label>Ready By</label>
      <input type="date" name="readyBy" class="form-control" value="<%= item.getReadyBy() != null ? sdf.format(item.getReadyBy()) : "" %>">
    </div>
    <button type="submit" class="btn btn-primary">Update Item</button>
    <a href="viewItems?projectId=<%= projectId %>" class="btn btn-secondary">Cancel</a>
  </form>
</div>
</body>
</html>
