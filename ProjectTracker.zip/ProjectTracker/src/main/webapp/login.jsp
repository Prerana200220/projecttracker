<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Use the implicit session object without redeclaring it.
    if (session != null && session.getAttribute("userRole") != null) {
        // User is already logged in, redirect to dashboard.
        response.sendRedirect("dashboard");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Welcome To REPUTE Project Planner &amp; Tracker</title>
    <link rel="icon" type="image/x-icon" href="<%= request.getContextPath() %>/favicon.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .top-bar { max-width: 900px; margin: 0 auto; padding: 10px; display: flex; justify-content: space-between; align-items: center; }
        .page-container { max-width: 900px; margin: 0 auto; padding: 20px; text-align: center; }
        .login-box { width: 350px; padding: 20px; margin: 20px auto; background: #fff; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .centered-list { display: inline-block; text-align: left; margin: 0 auto; }
    </style>
</head>
<body>
<div class="top-bar">
    <img src="<%= request.getContextPath() %>/logo/Logo.png" alt="Logo" style="height:90px;">
    <span class="fw-bold">REPUTE ENGINEERS PVT. LTD</span>
</div>
<div class="page-container">
    <h2 class="mt-3">Login - Welcome To REPUTE Project Planner &amp; Tracker</h2>
    <p>
       Streamline Your Workflow from Start to Finish.
       Manage your projects smoothly—from planning to completion—with simple tools and real-time updates.
    </p>
    <div class="login-box">
        <h5 class="mb-4">Login</h5>
        <form action="login" method="post">
            <div class="mb-3 text-start">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="mb-3 text-start">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="text-end">
                <a href="forgot-password.jsp" class="text-decoration-none">Forgot Password?</a> | 
                <!--  <a href="change_password.jsp" class="text-decoration-none">Change Password?</a> --> 
            </div>
            <button class="btn btn-primary w-100 mt-3" type="submit">Login</button>
            <% 
                String error = request.getParameter("error");
                if (error != null) { 
            %>
                <div class="alert alert-danger mt-3"><%= error %></div>
            <% } %>
            <p class="text-muted text-center mt-3">
                Note: Please contact admin if you face login issues.
            </p>
        </form>
    </div>
    <div class="mt-4">
        <p class="fw-bold">With Project Tracker, you can:</p>
        <ul class="list-unstyled centered-list">
            <li> Access your projects anytime, anywhere.</li>
            <li> Track tasks, deadlines, and deliverables.</li>
            <li> Collaborate seamlessly with your team.</li>
            <li> Receive automated updates and notifications.</li>
        </ul>
    </div>
    <footer class="mt-4">
        <strong>Designed &amp; developed by Prerana Salunkhe</strong>
    </footer>
</div>
</body>
</html>
