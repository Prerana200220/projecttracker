<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Retrieve the reset token from the request parameters.
    String token = request.getParameter("token");
    if (token == null || token.trim().isEmpty()) {
%>
    <h3>Invalid or missing token.</h3>
    <p>Please check your reset link and try again.</p>
<%
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { max-width: 400px; margin-top: 50px; }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center">Reset Password</h2>
    <form action="ResetPasswordServlet" method="post" class="mt-4">
        <!-- Hidden field to pass the reset token -->
        <input type="hidden" name="token" value="<%= token %>">
        
        <div class="mb-3">
            <label for="newPassword" class="form-label">New Password</label>
            <input type="password" id="newPassword" name="newPassword" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label for="confirmPassword" class="form-label">Confirm New Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" required>
        </div>
        
        <button type="submit" class="btn btn-primary w-100">Reset Password</button>
    </form>
</div>
</body>
</html>
