<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.example.Project" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    // Retrieve the project from the request attribute
    Project project = (Project) request.getAttribute("project");
    // Create a date formatter for date inputs
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    if (project == null) {
%>
    <h3>No project data found!</h3>
<%
    } else {
%>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Project</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-3">
    <h2>Edit Project</h2>
    <form action="editProject" method="post">
        <!-- Hidden field for project ID -->
        <input type="hidden" name="projectId" value="<%= project.getId() %>" />

        <!-- Row 1: Job No., Customer, City -->
        <div class="row mb-3">
            <div class="col">
                <label>Job No.</label>
                <input type="text" name="jobNo" class="form-control" 
                       value="<%= project.getJobNo() %>" required>
            </div>
            <div class="col">
                <label>Customer</label>
                <input type="text" name="customer" class="form-control" 
                       value="<%= project.getCustomer() %>" required>
            </div>
            <div class="col">
                <label>City</label>
                <input type="text" name="city" class="form-control" 
                       value="<%= project.getCity() %>" required>
            </div>
        </div>

        <!-- Row 2: Region, Segment, Project Manager -->
        <div class="row mb-3">
            <div class="col">
                <label>Region</label>
                <select name="region" class="form-control">
                    <option value="North"  <%= "North".equalsIgnoreCase(project.getRegion()) ? "selected" : "" %>>North</option>
                    <option value="East"   <%= "East".equalsIgnoreCase(project.getRegion()) ? "selected" : "" %>>East</option>
                    <option value="West"   <%= "West".equalsIgnoreCase(project.getRegion()) ? "selected" : "" %>>West</option>
                    <option value="South"  <%= "South".equalsIgnoreCase(project.getRegion()) ? "selected" : "" %>>South</option>
                    <option value="Export" <%= "Export".equalsIgnoreCase(project.getRegion()) ? "selected" : "" %>>Export</option>
                    <option value="AddMore" <%= "AddMore".equalsIgnoreCase(project.getRegion()) ? "selected" : "" %>>Add More</option>
                </select>
            </div>
            <div class="col">
                <label>Segment</label>
                <select name="segment" class="form-control">
                    <option value="Beverage"      <%= "Beverage".equalsIgnoreCase(project.getSegment()) ? "selected" : "" %>>Beverage</option>
                    <option value="Dairy"         <%= "Dairy".equalsIgnoreCase(project.getSegment()) ? "selected" : "" %>>Dairy</option>
                    <option value="Prepared Food" <%= "Prepared Food".equalsIgnoreCase(project.getSegment()) ? "selected" : "" %>>Prepared Food</option>
                    <option value="Equipment"     <%= "Equipment".equalsIgnoreCase(project.getSegment()) ? "selected" : "" %>>Equipment</option>
                    <option value="AddMore"       <%= "AddMore".equalsIgnoreCase(project.getSegment()) ? "selected" : "" %>>Add More</option>
                </select>
            </div>
            <div class="col">
                <label>Project Manager</label>
                <select name="projectManager" class="form-control">
                    <option value="Rohit BR"     <%= "Rohit BR".equalsIgnoreCase(project.getProjectManager()) ? "selected" : "" %>>Rohit BR</option>
                    <option value="Nitin Chede"  <%= "Nitin Chede".equalsIgnoreCase(project.getProjectManager()) ? "selected" : "" %>>Nitin Chede</option>
                    <option value="Jitendra Koli" <%= "Jitendra Koli".equalsIgnoreCase(project.getProjectManager()) ? "selected" : "" %>>Jitendra Koli</option>
                    <option value="Vignesh NPN"  <%= "Vignesh NPN".equalsIgnoreCase(project.getProjectManager()) ? "selected" : "" %>>Vignesh NPN</option>
                    <option value="AddMore"      <%= "AddMore".equalsIgnoreCase(project.getProjectManager()) ? "selected" : "" %>>Add More</option>
                </select>
            </div>
        </div>

        <!-- Project Name -->
        <div class="mb-3">
            <label>Project Name</label>
            <input type="text" name="projectName" class="form-control" 
                   value="<%= project.getProjectName() %>" required>
        </div>

        <!-- Project Value -->
        <div class="mb-3">
            <label>Project Value (INR)</label>
            <input type="number" name="projectValue" class="form-control" 
                   value="<%= project.getProjectValue() %>" required>
        </div>

        <!-- Currency Dropdown -->
        <div class="mb-3">
            <label>Currency</label>
            <select name="currency" class="form-control" required>
                <option value="INR" <%= "INR".equalsIgnoreCase(project.getCurrency()) ? "selected" : "" %>>INR</option>
                <option value="USD" <%= "USD".equalsIgnoreCase(project.getCurrency()) ? "selected" : "" %>>USD</option>
                <option value="UKP" <%= "UKP".equalsIgnoreCase(project.getCurrency()) ? "selected" : "" %>>UKP</option>
            </select>
            <small class="form-text text-muted">
                The stored value is in INR. This currency indicates how it's displayed.
            </small>
        </div>
        
        <!-- New fields: Payment Terms and Customer Required Date -->
        <div class="row mb-3">
            <div class="col">
                <label>Payment Terms</label>
                <input type="text" name="paymentTerms" class="form-control"
                       value="<%= project.getPaymentTerms() != null ? project.getPaymentTerms() : "" %>">
            </div>
            <div class="col">
                <label>Customer Required Date</label>
                <input type="date" name="customerRequiredDate" class="form-control"
                       value="<%= project.getCustomerRequiredDate() != null ? sdf.format(project.getCustomerRequiredDate()) : "" %>">
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">Update Project</button>
        <a href="dashboard" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
<%
    }
%>
