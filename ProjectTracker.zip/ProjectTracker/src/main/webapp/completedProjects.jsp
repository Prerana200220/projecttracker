<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.example.Project" %>
<%@ page import="java.text.DecimalFormat" %>
<%
    // Retrieve completed projects from the request.
    List<Project> projects = (List<Project>) request.getAttribute("completedProjects");
    if (projects == null) {
        projects = new java.util.ArrayList<>();
    }
    DecimalFormat inrFormat = new DecimalFormat("#,###");
%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Completed Projects - ProjectTracker</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    .container-fluid { padding: 15px; }
    .full-screen-table { width: 100%; margin: 0; }
    table { border-collapse: collapse; width: 100%; font-size: 13px; }
    th, td { border: 2px solid #333; padding: 4px; vertical-align: middle; }
    .header-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .header-left h2 { font-size: 1.5rem; font-weight: bold; color: #333; }
  </style>
</head>
<body>
<div class="container-fluid mt-3">
  <div class="header-row">
      <div class="header-left">
          <h2>Completed Projects</h2>
      </div>
      <div class="header-right">
          <a href="dashboard" class="btn btn-secondary" title="Back to Dashboard">Back to Dashboard</a>
      </div>
  </div>
  
  <table class="table table-bordered full-screen-table">
      <thead class="table-dark">
          <tr>
              <th>Sr.No.</th>
              <th>Job No.</th>
              <th>Customer</th>
              <th>City</th>
              <th>Region</th>
              <th>Segment</th>
              <th>Project Manager</th>
              <th>Project Name</th>
              <th class="text-end">Project Value</th>
              <th>Currency</th>
              <th>Upload File</th>
              <th>Actions</th>
          </tr>
      </thead>
      <tbody>
      <%
          int srNo = 1;
          for (Project p : projects) {
      %>
          <tr>
              <td><%= srNo++ %></td>
              <td><%= p.getJobNo() %></td>
              <td><%= p.getCustomer() %></td>
              <td><%= p.getCity() %></td>
              <td><%= p.getRegion() %></td>
              <td><%= p.getSegment() %></td>
              <td><%= p.getProjectManager() %></td>
              <td><%= p.getProjectName() %></td>
              <td class="text-end">
                  <%
                      long valueInINR = p.getProjectValue();
                      String dispCurrency = p.getCurrency();
                      if(dispCurrency.equalsIgnoreCase("USD")){
                          double valueInUSD = valueInINR / 87.38;
                          out.print("$" + String.format("%.2f", valueInUSD));
                      } else if(dispCurrency.equalsIgnoreCase("UKP") || dispCurrency.equalsIgnoreCase("GBP")){
                          double valueInUKP = valueInINR / 110.00;
                          out.print("£" + String.format("%.2f", valueInUKP));
                      } else {
                          out.print("₹" + inrFormat.format(valueInINR));
                      }
                  %>
              </td>
              <td><%= p.getCurrency() %></td>
              <td>
                  <form class="file-upload" action="<%= request.getContextPath() %>/uploadFileServlet" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="projectId" value="<%= p.getId() %>">
                      <input type="file" name="file" class="form-control form-control-sm" required>
                      <button type="submit" class="btn btn-success btn-sm" title="Upload File">
                          <i class="bi bi-upload"></i>
                      </button>
                  </form>
                  <%
                      if(p.getFileName() != null && !p.getFileName().isEmpty()){
                  %>
                      <div class="mt-1">
                          <i class="bi bi-file-earmark"></i>
                          <a href="<%= request.getContextPath() %>/uploads/<%= p.getFileName() %>" target="_blank">
                              <%= p.getFileName() %>
                          </a>
                      </div>
                  <%
                      }
                  %>
              </td>
              <td>
                  <a class="btn btn-warning btn-sm" href="editProject?projectId=<%= p.getId() %>" title="Update">
                      <i class="bi bi-pencil-square"></i>
                  </a>
                  <a class="btn btn-danger btn-sm" href="deleteProject?projectId=<%= p.getId() %>" title="Delete"
                     onclick="return confirm('Are you sure you want to delete project: <%= p.getProjectName() %>?');">
                      <i class="bi bi-trash"></i>
                  </a>
                  <!-- View Completed Items for this project.
                       This link should go to a new servlet that shows only completed items for that project.
                  -->
                  <a class="btn btn-info btn-sm" href="completedItems?projectId=<%= p.getId() %>" title="View Completed Items">
                      <i class="bi bi-eye"></i>
                  </a>
              </td>
          </tr>
      <%
          }
      %>
      </tbody>
  </table>
  
  <!-- Pagination (Placeholder) -->
  <div class="d-flex justify-content-end">
      <span class="me-2">Page 1 of n</span>
      <button class="btn btn-sm btn-outline-primary me-2">Next</button>
      <input type="text" class="form-control-sm me-2" placeholder="Jump to page">
      <button class="btn btn-sm btn-primary">Go</button>
  </div>
</div>
</body>
</html>
