<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password - ProjectTracker</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .forgot-password-container {
            display: flex; justify-content: center; align-items: center; height: 100vh;
        }
        .forgot-password-box {
            width: 350px; padding: 20px; background: #fff; border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<div class="forgot-password-container">
    <div class="forgot-password-box">
        <h3 class="text-center mb-4">Forgot Password</h3>
        <p class="text-center text-muted">Enter your email to receive reset instructions.</p>

        <form action="SendResetLinkServlet" method="post">
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <button class="btn btn-primary w-100" type="submit">Send Reset Link</button>

            <% String message = request.getParameter("message");
               if (message != null) { %>
                <div class="alert alert-info mt-3"><%= message %></div>
            <% } %>

            <div class="text-center mt-3">
                <a href="login.jsp" class="text-decoration-none">Back to Login</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>
