<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*, java.text.*, com.example.Project, com.example.Item, java.util.Calendar, java.util.concurrent.TimeUnit" %>
<%!
    // -------------------------------------------------------
    // 1. Define base dates for week calculations (midnight)
    // -------------------------------------------------------
    private static final Calendar base2025;
    private static final Calendar base2026;
    static {
        base2025 = Calendar.getInstance();
        base2025.set(2025, Calendar.APRIL, 1, 0, 0, 0);
        base2025.set(Calendar.MILLISECOND, 0);

        base2026 = Calendar.getInstance();
        base2026.set(2026, Calendar.JANUARY, 8, 0, 0, 0);
        base2026.set(Calendar.MILLISECOND, 0);
    }

    // -------------------------------------------------------
    // 2. Compute a week key (e.g. "W-15(25)") from a planned date
    // -------------------------------------------------------
    public String getWeekKey(Date plannedDate) {
        if (plannedDate == null) return null;

        // Force plannedDate to midnight to avoid partial-day issues
        Calendar cal = Calendar.getInstance();
        cal.setTime(plannedDate);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date plannedMidnight = cal.getTime();

        long dayMillis = 24L * 60L * 60L * 1000L;
        int year = cal.get(Calendar.YEAR);
        if (year == 2025) {
            long diffMillis = plannedMidnight.getTime() - base2025.getTimeInMillis();
            long diffDays = TimeUnit.DAYS.convert(diffMillis, TimeUnit.MILLISECONDS);
            int week = 14 + (int)(diffDays / 7);
            if (week < 14 || week > 52) return null;
            return "W-" + week + "(25)";
        } else if (year == 2026) {
            long diffMillis = plannedMidnight.getTime() - base2026.getTimeInMillis();
            long diffDays = TimeUnit.DAYS.convert(diffMillis, TimeUnit.MILLISECONDS);
            int week = 1 + (int)(diffDays / 7);
            if (week < 1 || week > 14) return null;
            return "W-" + week + "(26)";
        }
        return null;
    }
%>

<%
    // -------------------------------------------------------
    // 3. Build the list of week columns
    // -------------------------------------------------------
    List<String> weekColumns = new ArrayList<>();
    for (int w = 14; w <= 52; w++) {
        weekColumns.add("W-" + w + "(25)");
    }
    for (int w = 1; w <= 14; w++) {
        weekColumns.add("W-" + w + "(26)");
    }

    // -------------------------------------------------------
    // 4. Retrieve projects from request scope
    // -------------------------------------------------------
    List<Project> projects = (List<Project>) request.getAttribute("projects");
    if (projects == null) {
        projects = new ArrayList<>();
    }

    // -------------------------------------------------------
    // 5. Calculate totals and counts per week across ALL items
    // -------------------------------------------------------
    Map<String, Double> weekTotals = new HashMap<>();
    Map<String, Integer> weekCounts = new HashMap<>();
    for (String wk : weekColumns) {
        weekTotals.put(wk, 0.0);
        weekCounts.put(wk, 0);
    }

    for (Project p : projects) {
        if (p.getItems() != null) {
            for (Item it : p.getItems()) {
                // Skip items with no planned date or already completed
                if (it.getPlannedDate() == null || it.getCompletedDate() != null) {
                    continue;
                }
                String wk = getWeekKey(it.getPlannedDate());
                if (wk != null) {
                    double oldVal = weekTotals.getOrDefault(wk, 0.0);
                    weekTotals.put(wk, oldVal + it.getTotalValue());
                    int oldCount = weekCounts.getOrDefault(wk, 0);
                    weekCounts.put(wk, oldCount + 1);
                }
            }
        }
    }

    // -------------------------------------------------------
    // 6. Use #,### to avoid showing .00
    // -------------------------------------------------------
    DecimalFormat df = new DecimalFormat("#,###");

    // -------------------------------------------------------
    // 7. Variables for item rows
    // -------------------------------------------------------
    Integer lastProjectId = null;   // to detect job number change
    boolean alternateColor = false; // toggles job no color green/blue
    int srNo = 1;                   // reset to 1 when job no changes

    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); // for planned/readyBy dates

    // -------------------------------------------------------
    // 8. "Today" Calendar for highlighting
    // -------------------------------------------------------
    Calendar calToday = Calendar.getInstance();
    calToday.setTime(new Date());  // "now"
%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Weekly Planning Report - Item Wise</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Optional: html2canvas and jsPDF for PDF download -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
      font-size: 13px;
    }
    th, td {
      border: 1px solid #333 !important;
      padding: 4px !important;
      text-align: center !important;
      vertical-align: middle !important;
    }
    .item-desc-col {
      min-width: 400px !important;
      white-space: nowrap !important;
      text-align: left !important;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .totals-row {
      background-color: #333 !important;
      color: #fff !important;
      font-weight: bold !important;
    }
    .info-header {
      background-color: black !important;
      color: white !important;
    }
    .job-green {
      background-color: green !important;
      color: white !important;
    }
    .job-blue {
      background-color: blue !important;
      color: white !important;
    }
    .week-heading-even {
      background-color: green !important;
      color: white !important;
    }
    .week-heading-odd {
      background-color: pink !important;
      color: white !important;
    }
    .week-ready {
      color: green !important;
      font-weight: bold !important;
    }
    .nowrap {
      white-space: nowrap !important;
    }
    /* Sticky header rows */
    thead tr.totals-row th {
      position: sticky;
      top: 0;
      background-color: #333;
      color: white !important;
      z-index: 3;
    }
    thead tr.info-header th {
      position: sticky;
      top: 30px;  /* height of the totals row */
      background-color: black;
      color: white !important;
      z-index: 2;
    }
  </style>
</head>
<body>
<div class="container-fluid mt-3">
  <h2>Weekly Planning Report - Item Wise</h2>
  
  <!-- Buttons: Print, Back to Dashboard -->
  <div class="mb-3">
    <button class="btn btn-primary" onclick="window.print()">Print</button>
    <!-- <button class="btn btn-success" onclick="downloadPDF()">Download PDF</button> -->
    <a href="dashboard" class="btn btn-secondary">Back to Dashboard</a>
  </div>
  
  <!-- Table container for PDF capture -->
  <div id="pdfContent">
    <table class="table table-bordered">
      <thead>
        <!-- Totals row (sticky) -->
        <tr class="totals-row">
          <!-- 14 fixed columns for item info -->
          <th colspan="14">Totals</th>
          <% for (String wk : weekColumns) {
               double sumVal = weekTotals.getOrDefault(wk, 0.0);
          %>
            <th><%= (sumVal != 0.0) ? df.format(sumVal) : "" %></th>
          <% } %>
        </tr>
        
        <!-- Column headers (sticky) -->
        <tr class="info-header">
          <th>Sr.No.</th>
          <th>Job No.</th>
          <th>Project Manager</th>
          <th>ERP No.</th>
          <th class="item-desc-col">Item Description</th>
          <th>Capacity</th>
          <th>Qty</th>
          <th>Unit Value</th>
          <th>Total Value</th>
          <th>Responsibility</th>
          <th class="nowrap">Planned Date</th>
          <th>Reason for Delay</th>
          <th>Status</th>
          <th class="nowrap">Ready By</th>
          <%
            int idx = 0;
            for (String col : weekColumns) {
                int count = weekCounts.getOrDefault(col, 0);
                String cssClass = (idx % 2 == 0) ? "week-heading-even" : "week-heading-odd";
          %>
            <th class="<%= cssClass %>"><%= col %>(<%= count %>)</th>
          <%
                idx++;
            }
          %>
        </tr>
      </thead>
      
      <tbody>
        <%
           for (Project p : projects) {
             if (p.getItems() == null) continue;
             for (Item it : p.getItems()) {
                 // Skip items with no planned date or completed
                 if (it.getPlannedDate() == null || it.getCompletedDate() != null) {
                     continue;
                 }
                 
                 // Reset srNo & toggle color if new project
                 if (lastProjectId == null || !lastProjectId.equals(p.getId())) {
                     srNo = 1;
                     alternateColor = !alternateColor;
                     lastProjectId = p.getId();
                 }

                 // Check if planned date == today for red highlight
                 boolean highlight = false;
                 Calendar calItem = Calendar.getInstance();
                 calItem.setTime(it.getPlannedDate());
                 if (calItem.get(Calendar.YEAR) == calToday.get(Calendar.YEAR)
                     && calItem.get(Calendar.DAY_OF_YEAR) == calToday.get(Calendar.DAY_OF_YEAR)) {
                     highlight = true;
                 }

                 // Inline style for each <td>
                 String highlightStyle = highlight ? "color:red !important; font-weight:bold !important;" : "";

                 String plannedDateStr = sdf.format(it.getPlannedDate());
                 String delayReason = (it.getDelayReason() != null && !it.getDelayReason().trim().isEmpty()) ? it.getDelayReason() : "";
                 String status = (it.getStatus() != null && !it.getStatus().trim().isEmpty()) ? it.getStatus() : "";
                 String readyByStr = (it.getReadyBy() != null) ? sdf.format(it.getReadyBy()) : "";
                 String itemWeekKey = getWeekKey(it.getPlannedDate());
        %>
        <tr>
          <td style="<%= highlightStyle %>"><%= srNo++ %></td>
          <td class="<%= (alternateColor ? "job-green" : "job-blue") %>" style="<%= highlightStyle %>">
            <%= p.getJobNo() %>
          </td>
          <td style="<%= highlightStyle %>"><%= p.getProjectManager() %></td>
          <td style="<%= highlightStyle %>"><%= it.getErpNo() %></td>
          <td style="<%= highlightStyle %>" title="<%= it.getItemDescription() %>"><%= it.getItemDescription() %></td>
          <td style="<%= highlightStyle %>"><%= it.getCapacity() %></td>
          <td style="<%= highlightStyle %>"><%= it.getQty() %></td>
          <td style="<%= highlightStyle %>"><%= df.format(it.getUnitValue()) %></td>
          <td style="<%= highlightStyle %>"><%= df.format(it.getTotalValue()) %></td>
          <td style="<%= highlightStyle %>"><%= it.getResponsibility() %></td>
          <td class="nowrap" style="<%= highlightStyle %>"><%= plannedDateStr %></td>
          <td style="<%= highlightStyle %>"><%= delayReason %></td>
          <td style="<%= highlightStyle %>"><%= status %></td>
          <td class="nowrap" style="<%= highlightStyle %>"><%= readyByStr %></td>
          <%
             for (String wc : weekColumns) {
                 if (wc.equals(itemWeekKey)) {
          %>
            <td class="week-ready" style="<%= highlightStyle %>">Planned</td>
          <%
                 } else {
          %>
            <td></td>
          <%
                 }
             }
          %>
        </tr>
        <%
             } // end item loop
           } // end project loop
        %>
      </tbody>
    </table>
  </div> <!-- End pdfContent -->
</div>

<script>
  // Optional: PDF download feature
  function downloadPDF() {
      const pdfContent = document.getElementById("pdfContent");
      html2canvas(pdfContent, {
          scale: 2,
          scrollX: 0,
          scrollY: 0,
          useCORS: true
      }).then(function(canvas) {
          const { jsPDF } = window.jspdf;
          const pdf = new jsPDF('l', 'pt', [canvas.width, canvas.height]);
          const imgData = canvas.toDataURL("image/png");
          pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
          pdf.save("weekly_planning_report.pdf");
      });
  }
</script>
</body>
</html>
