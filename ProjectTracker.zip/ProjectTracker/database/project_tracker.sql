CREATE DATABASE  project_tracker;
USE project_tracker;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_no VARCHAR(50) UNIQUE NOT NULL,
    customer VARCHAR(100),
    city VARCHAR(50),
    region VARCHAR(50),
    segment VARCHAR(50),
    project_manager VARCHAR(100),
    project_name VARCHAR(255),
    project_value DECIMAL(15,2)
);

-- Items table
CREATE TABLE  items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
     erpNo VARCHAR(500) NOT NULL,
    -- Using LONGTEXT for extremely large item descriptions (up to 4GB).
    item_description LONGTEXT,
    capacity VARCHAR(50),
    qty INT,
    unit_value DECIMAL(15,2),
    -- total_value is auto-calculated in MySQL:
    total_value DECIMAL(15,2) GENERATED ALWAYS AS (qty * unit_value) STORED,
    responsibility ENUM('Unit1','Unit2','Bought Out','Import'),
    planned_date DATE,
    completed_date DATE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);
drop DATABASE  project_tracker;
INSERT INTO users (username, password) VALUES ('admin', 'admin123');
ALTER TABLE projects 
  MODIFY project_value DECIMAL(15,2);
SHOW CREATE TABLE projects;
ALTER TABLE projects MODIFY COLUMN project_value BIGINT;

ALTER TABLE projects 
  MODIFY COLUMN project_value BIGINT,
  ADD COLUMN currency VARCHAR(10);
ALTER TABLE items ADD COLUMN erpNo VARCHAR(100);
select * from projects;
ALTER TABLE projects ADD COLUMN fileName VARCHAR(255);
ALTER TABLE projects ADD COLUMN status VARCHAR(20) DEFAULT 'Active';
SELECT * FROM projects WHERE status = 'Completed'

 ALTER TABLE users ADD COLUMN email VARCHAR(100) UNIQUE;
UPDATE users SET email = 'preranasalunkhe2002@gmail.com' WHERE email IS NULL;
ALTER TABLE users ADD COLUMN reset_token VARCHAR(255) NULL;
select * from users;
SELECT * FROM items WHERE project_id = 17 AND completed_date IS NOT NULL;
SELECT * FROM items WHERE project_id = 15 AND completed_date IS NOT NULL;
SELECT * FROM items WHERE project_id = 15 AND completed_date IS  NULL;
SELECT * FROM items
WHERE project_id = 25
AND planned_date IS  NOT NULL;
ALTER TABLE items ADD COLUMN delay_reason VARCHAR(255) NULL;
ALTER TABLE items ADD COLUMN delay_reason VARCHAR(255) NULL;
DESCRIBE items;
select * from items;
ALTER TABLE items ADD COLUMN delay_reason VARCHAR(255) NULL;












